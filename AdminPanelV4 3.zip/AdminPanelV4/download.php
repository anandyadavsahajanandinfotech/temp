<?php 
require_once("configuration.php");
 $input = @file_get_contents("php://input");
 $event_json = json_decode($input,true);
 $query = 'query';
		if(isset($event_json['app']))
	//	if(true)
		{
			$array_out = array();				
			$query=mysqli_query($conn,"UPDATE `videotable` SET `downloads`=downloads+1 WHERE id='".$event_json['id']."'");
		    $output=array( "code" => "200", "msg" => "Success");
			print_r(json_encode($output, true));	
					
				
		}	
		else
		{
			$array_out = array();
					
			 $array_out[] = 
				array(
				"response" =>"You dont have permission to this URL");
			
			$output=array( "code" => "201","msg" => $array_out);
			print_r(json_encode($output, true));
		}
?>