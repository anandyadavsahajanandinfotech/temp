<?php 
	require("includes/connection.php");
	require("includes/function.php");
	require("language/language.php");

	$response=array();


	switch ($_POST['action']) {
		case 'toggle_status':
			$id=$_POST['id'];
			$for_action=$_POST['for_action'];
			$column=$_POST['column'];
			$tbl_id=$_POST['tbl_id'];
			$table_nm=$_POST['table'];

			if($for_action=='active'){
				$data = array($column  =>  '1');
			    $edit_status=Update($table_nm, $data, "WHERE $tbl_id = '$id'");
			}else{
				$data = array($column  =>  '0');
			    $edit_status=Update($table_nm, $data, "WHERE $tbl_id = '$id'");
			}
			
	      	$response['status']=1;
	      	$response['action']=$for_action;
	      	echo json_encode($response);
			break;

		case 'delete_quote':

			$id=$_POST['id'];
			$table_nm=$_POST['table'];

			if($table_nm!='tbl_img_quotes'){
				Delete($table_nm,'id='.$id);	
			}
			else{
				$sql="SELECT * FROM $table_nm WHERE `id`='$id'";
				$res=mysqli_query($mysqli, $sql);
				$row=mysqli_fetch_assoc($res);
				if($row['video_thumb']!="")
				{
					unlink($row['video_link']);
					unlink($row['video_thumb']);
				}

				Delete($table_nm,'id='.$id);
			}
			
	      	$response['status']=1;
	      	echo json_encode($response);
			break;

		case 'multi_delete':

			$ids=implode(",", $_POST['id']);

			$sql="SELECT * FROM tbl_img_quotes WHERE `id` IN ($ids)";
			$res=mysqli_query($mysqli, $sql);
			while ($row=mysqli_fetch_assoc($res)){
				if($row['quote_image']!="")
				{
					unlink('images/'.$row['quote_image']);
					unlink('images/thumbs/'.$row['quote_image']);
				}
			}
			$deleteSql="DELETE FROM tbl_img_quotes WHERE `id` IN ($ids)";

			mysqli_query($mysqli, $deleteSql);
			
	      	$response['status']=1;
	      	echo json_encode($response);
			break;

		
		default:
			$response['status']=-2;
			$response['message']='No method available !';
	      	echo json_encode($response);
			break;
	}

?>