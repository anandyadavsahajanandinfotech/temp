<?php include("includes/header.php");

	require("includes/function.php");
	require("language/language.php");

	require_once("thumbnail_images.class.php");
     require("configuration.php");
	 
	if(isset($_POST['submit']) and isset($_GET['add']))
	{

	
     
     
     
	   $category_image=$_FILES['category_image']['name'];
	    //Main Image
	   $tpath1='category1src/'.$category_image; 			 
	   
    
 	   if(!is_dir('category1src'))
	   {
	
	   		mkdir('category1src', 0777);
	   		
	   }			

     
	   
	   if (move_uploaded_file($_FILES["category_image"]["tmp_name"], $tpath1)) {
	      
		  $data = array( 
			    'category'  =>  $_POST['category_name'],
			   'image'  =>  "category1src/".$category_image
			    );		
 
 		   $qry = Insert('category',$data);	

 	        $cat_id=mysqli_insert_id($mysqli);	

 	     if(!is_dir('category1src/'.$cat_id))
	       {
	
	   		mkdir('category1src/'.$cat_id, 0777);
	   		
	      }			
       
         } else {
         
         echo "failed";
             
             
         }
         
    

		$_SESSION['msg']="10";
 
		header( "Location:manage_category.php");
		exit;	


		 
		
	}
	


?>
<div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="page_title_block">
            <div class="col-md-5 col-xs-12">
              <div class="page_title"><?php if(isset($_GET['cat_id'])){?>Edit<?php }else{?>Add<?php }?> Category</div>
            </div>
          </div>
          <div class="clearfix"></div>
          <div class="row mrg-top">
            <div class="col-md-12">
               
              <div class="col-md-12 col-sm-12">
                <?php if(isset($_SESSION['msg'])){?> 
               	 <div class="alert alert-success alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                	<?php echo $client_lang[$_SESSION['msg']] ; ?></a> </div>
                <?php unset($_SESSION['msg']);}?>	
              </div>
            </div>
          </div>
          <div class="card-body mrg_bottom"> 
            <form action="" name="addeditcategory" method="post" class="form form-horizontal" enctype="multipart/form-data">
            	<input  type="hidden" name="cat_id" value="<?php echo $_GET['cat_id'];?>" />

              <div class="section">
                <div class="section-body">
                  <div class="form-group">
                    <label class="col-md-3 control-label">Category Name :-</label>
                    <div class="col-md-6">
                      <input type="text" name="category_name" id="category_name" value="<?php if(isset($_GET['cat_id'])){echo $row['category_name'];}?>" class="form-control" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-md-3 control-label">Select Image :-
                    <p class="control-label-help">(Recommended resolution: 274,180)</p>
                    </label>
                    <div class="col-md-6">
                      <div class="fileupload_block">
                        <input type="file" name="category_image" value="fileupload" id="fileupload">
                        
                        	  <div class="fileupload_img"><img type="image" src="assets/images/add-image.png" alt="category image" /></div>
                        	 
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-md-3 control-label">&nbsp; </label>
                    <div class="col-md-6">
                      <?php if(isset($_GET['cat_id']) and $row['category_image']!="") {?>
                        	  <div class="block_wallpaper"><img src="thumb.php?src=images/<?php echo $row['category_image'];?>&size=300x250" alt="category image" /></div>
                        	<?php } ?>
                    </div>
                  </div><br>
                  <div class="form-group">
                    <div class="col-md-9 col-md-offset-3">
                      <button type="submit" name="submit" class="btn btn-primary">Save</button>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
        
<?php include("includes/footer.php");?>       
