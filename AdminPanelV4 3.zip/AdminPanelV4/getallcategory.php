<?php 
require_once("configuration.php");
 $input = @file_get_contents("php://input");
 $event_json = json_decode($input,true);
 $query = 'query';
		// if(isset($event_json['app']))
		if(true)
		{
			$array_out = array();				
			$query=mysqli_query($conn,"SELECT * FROM `category`");
			while($row=mysqli_fetch_array($query))
				{
					$array_out[] = 
						array(
						"id" => $row['id'],
						"category" => $row['category'],
						"image_url" => $dirname."/".$row['image']					
					);
				}
			
				$output=array( "code" => "200", "msg" => $array_out);
				print_r(json_encode($output, true));
		}	
		else
		{
			$array_out = array();
					
			 $array_out[] = 
				array(
				"response" =>"You dont have permission to this URL");
			
			$output=array( "code" => "201","msg" => $array_out);
			print_r(json_encode($output, true));
		}
?>