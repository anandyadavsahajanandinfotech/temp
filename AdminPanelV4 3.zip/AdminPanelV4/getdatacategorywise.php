<?php 
require_once("configuration.php");
 $input = @file_get_contents("php://input");
 $event_json = json_decode($input,true);
 $query = 'query';
		// if(isset($event_json['app']))
		if(true)
		{
			$array_out = array();
			
			if ($event_json['cat'] == 'Latest')
			{ 
				$query=mysqli_query($conn,"SELECT * FROM `videotable` ORDER BY rand()");
			} 
			else if ($event_json['cat'] == 'Popular')
			{
				$query=mysqli_query($conn,"SELECT * FROM `videotable` ORDER BY `videotable`.`downloads` DESC");
			}
			else
			{
				$query=mysqli_query($conn,"SELECT * FROM `videotable` WHERE category ='".$event_json['cat']."' ORDER BY id DESC");				
			}
			while($row=mysqli_fetch_array($query))
				{
					$array_out[] = 
						array(
						"id" => $row['id'],
						"title" => $row['title'],
						"video_thumb" => $dirname."/".$row['video_thumb'],
						"video_link" => $dirname."/".$row['video_link'],
						"video_zip" => $dirname."/".$row['video_zip']
					
					);
				}
			
				$output=array( "code" => "200", "msg" => $array_out);
				print_r(json_encode($output, true));
		}	
		else
		{
			$array_out = array();
					
			 $array_out[] = 
				array(
				"response" =>"You dont have permission to this URL");
			
			$output=array( "code" => "201","msg" => $array_out);
			print_r(json_encode($output, true));
		}
?>