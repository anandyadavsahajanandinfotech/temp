<?php
require_once("configuration.php");
$input = @file_get_contents("php://input");
// $_POST = json_decode($input, true);
// $query = 'query';

$start = 0;


$page = $_POST['page'];

$limit = 10;

$tname = "videotable";


// if(isset($_POST['app']))
if (true) {
	$array_out = array();

	if ($_POST['cat'] == 'Latest') {


		$query = "SELECT * FROM `videotable` ORDER BY rand()";

		$total = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM $tname  ORDER BY rand()"));

		if ($total < $limit) {
			$limit = $total;
		}
	} else if ($_POST['cat'] == 'Popular') {
		// echo "<script>console.log('Debug Objects: " . "cat" . "' );</script>";

		$query = "SELECT * FROM `videotable` ORDER BY `videotable`.`downloads` DESC";
		$total = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM $tname  ORDER BY `videotable`.`downloads` DESC"));

		// echo "<script>console.log('Debug Objects: total" . "$total" . "' );</script>";
		// echo "<script>console.log('Debug Objects: limit " . "$limit" . "' );</script>";
		if ($total < $limit) {
			$limit = $total;
		}
	} else if (isset($_POST['search'])) {
		$search  = $_POST['search'];

		if ($_POST['search'] == 'Latest') {


			$query = "SELECT * FROM `videotable` ORDER BY id DESC";

			$total = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM $tname  ORDER BY rand()"));

			if ($total < $limit) {
				$limit = $total;
			}
		} else if ($_POST['search'] == 'Popular') {

			$query = "SELECT * FROM `videotable` ORDER BY `videotable`.`downloads` DESC";
			$total = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM $tname  ORDER BY `videotable`.`downloads` DESC"));

			if ($total < $limit) {
				$limit = $total;
			}
		} else {
			$query = "SELECT * FROM `videotable` WHERE title like '%$search%' or category ='" . $_POST['search'] . "'  ORDER BY id DESC";
			$total = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM `videotable` WHERE title like '%$search%' or category ='" . $_POST['search'] . "'  "));


			if ($total < $limit) {
				$limit = $total;
			}
		}
	} else {


		$cat = $_POST['cat'];

		$query = "SELECT * FROM `videotable` WHERE  category ='" . $_POST['cat'] . "' ORDER BY id DESC";

		$total = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM $tname where category ='" . $_POST['cat'] . "'"));

		if ($total < $limit) {
			$limit = $total;
		}
	}


	$page_limit = $total / $limit;

	if ($page <= $page_limit) {

		$start = ($page - 1) * $limit;

		//SQL query to fetch data of a range 
		$runsql = $query . " limit $start,$limit ";



		$result = mysqli_query($conn, $runsql);



		while ($row = mysqli_fetch_array($result)) {
			$array_out[] =
				array(
					"id" => $row['id'],
					"title" => $row['title'],
					"video_thumb" => $dirname . "/" . $row['video_thumb'],
					"video_link" => $dirname . "/" . $row['video_link'],
					"video_zip" => $dirname . "/" . $row['video_zip']

				);
		}

		$output = array("code" => "200", "msg" => $array_out);

		print_r(json_encode($output, true));
	}
} else {
	$array_out = array();

	$array_out[] =
		array(
			"response" => "You dont have permission to this URL"
		);

	$output = array("code" => "201", "msg" => $array_out);
	print_r(json_encode($output, true));
}
