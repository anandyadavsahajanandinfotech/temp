<?php include("includes/header.php");

$qry_cat="SELECT COUNT(*) as num FROM category";
$total_category= mysqli_fetch_array(mysqli_query($mysqli,$qry_cat));
$total_category = $total_category['num'];

$qry_quotes="SELECT COUNT(*) as num FROM category";
$total_quotes = mysqli_fetch_array(mysqli_query($mysqli,$qry_quotes));
$total_quotes = $total_quotes['num'];

$qry_img_quotes="SELECT COUNT(*) as num FROM videotable";
$total_img_quotes = mysqli_fetch_array(mysqli_query($mysqli,$qry_img_quotes));
$total_img_quotes = $total_img_quotes['num'];

?>       

        <div class="btn-floating" id="help-actions">
      <div class="btn-bg"></div>
      <button type="button" class="btn btn-default btn-toggle" data-toggle="toggle" data-target="#help-actions"> <i class="icon fa fa-plus"></i> <span class="help-text">Shortcut</span> </button>
      <div class="toggle-content">
        <ul class="actions">
          <li><a href="https://codecanyon.net/user/infiapp" target="_blank">Website</a></li>
          <li><a href="https://codecanyon.net/item/lyrical-video-status-maker-add-photos-into-videos-mv-video-status-creator/29805310" target="_blank">About</a></li>
        </ul>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12"> <a href="add_video_templates.php" class="card card-banner card-green-light">
        <div class="card-body"> <i class="icon fa fa-video-camera fa-4x"></i>
          <div class="content">
            <div class="title">Video Templates</div>
            <div class="value"><span class="sign"></span><?php echo $total_img_quotes;?></div>
          </div>
        </div>
        </a> </div>
         <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12"> <a href="manage_category.php" class="card card-banner card-yellow-light">
        <div class="card-body"><i class="icon fa fa-folder-open fa-4x "></i>
          <div class="content">
            <div class="title">Video Category</div>
            <div class="value"><span class="sign"></span><?php echo $total_category;?></div>
          </div>
        </div>
        </a> </div>
      
     
     
     
    </div>
	
	<div class="custom-section">
		<?php

	require("includes/function.php");
	require("language/language.php");
	
	
	$tname ="category";

  if(isset($_POST['data_search']))
   {

      $qry="SELECT * FROM $tname                   
                  WHERE `category` LIKE '%".addslashes($_POST['search_value'])."%'
                  ORDER BY `category`";
 
     $result=mysqli_query($mysqli,$qry); 

   }
   else
   {
	
	//Get all Category 
	 
      $tableName="category";   
      $targetpage = "manage_category.php"; 
      $limit = 12; 
      
      $query = "SELECT COUNT(*) as num FROM $tableName";
      $total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query));
      $total_pages = $total_pages['num'];
      
      $stages = 3;
      $page=0;
      if(isset($_GET['page'])){
      $page = mysqli_real_escape_string($mysqli,$_GET['page']);
      }
      if($page){
        $start = ($page - 1) * $limit; 
      }else{
        $start = 0; 
        } 
      
     $qry="SELECT * FROM $tableName
                   ORDER BY category DESC LIMIT $start, $limit";
 
     $result=mysqli_query($mysqli,$qry); 
	
    } 

	if(isset($_GET['cat_id']))
	{ 

    Delete($tname,'id='.$_GET['cat_id'].'');
		
		$cat_res=mysqli_query($mysqli,'SELECT * FROM $tname WHERE id=\''.$_GET['id'].'\'');
		$cat_res_row=mysqli_fetch_assoc($cat_res);

		if($cat_res_row['category_image']!="")
	    {
	    	unlink('images/'.$cat_res_row['category_image']);
			  unlink('images/thumbs/'.$cat_res_row['category_image']);
		}
 
		Delete($tname,'id='.$_GET['id'].'');

		$_SESSION['msg']="12";
		header( "Location:manage_category.php");
		exit;
		
	}	

   
  //Active and Deactive status
if(isset($_GET['status_deactive_id']))
{
   $data = array('status'  =>  '0');
  
   $edit_status=Update($tname, $data, "WHERE cid = '".$_GET['status_deactive_id']."'");
  
   $_SESSION['msg']="14";
   header( "Location:manage_category.php");
   exit;
}
if(isset($_GET['status_active_id']))
{
    $data = array('status'  =>  '1');
    
    $edit_status=Update('$tname', $data, "WHERE cid = '".$_GET['status_active_id']."'");
    
    $_SESSION['msg']="13";   
    header( "Location:manage_category.php");
    exit;
}  
	 
?>
			<div class="row">
      <div class="col-xs-12">
        <div class="card mrg_bottom">
          <div class="page_title_block">
            <div class="col-md-5 col-xs-12">
              <div class="page_title">Manage Categories</div>
            </div>
            <div class="col-md-7 col-xs-12">
              <div class="search_list">
                <div class="search_block">
                  <form  method="post" action="">
                  <input class="form-control input-sm" placeholder="Search..." aria-controls="DataTables_Table_0" type="search" name="search_value" required>
                        <button type="submit" name="data_search" class="btn-search"><i class="fa fa-search"></i></button>
                  </form>  
                </div>
                <div class="add_btn_primary"> <a href="add_category.php?add=yes"><i class="fa fa-pencil" aria-hidden="true"></i></a> </div>
              </div>
            </div>
          </div>
           <div class="clearfix"></div>
          <div class="row mrg-top">
            <div class="col-md-12">
               
              <div class="col-md-12 col-sm-12">
                <?php if(isset($_SESSION['msg'])){?> 
                 <div class="alert alert-success alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                  <?php echo $client_lang[$_SESSION['msg']] ; ?></a> </div>
                <?php unset($_SESSION['msg']);}?> 
              </div>
            </div>
          </div>
          <div class="col-md-12 mrg-top">
            <div class="row">
              <?php 
              $i=0;
              while($row=mysqli_fetch_array($result))
              {         
          ?>
              <div class="col-lg-12 col-sm-12 col-xs-12">
                <div class="block_wallpaper add_wall_category">
					<span><img src="<?php echo $row['image'];?>" /></span>
					<div class="wall_category_block">
                    <h2><?php echo $row['category'];?></h2>
                    <span><?php echo $row['title'];?></span>    
                  </div>
                  <div class="wall_image_title">
                    
                    <ul>                
                     <!-- <li><a href="add_category.php?cat_id=<?php echo $row['id'];?>" data-toggle="tooltip" data-tooltip="Edit"><i class="fa fa-edit"></i></a></li> -->              
                      <li><a href="?cat_id=<?php echo $row['id'];?>" data-toggle="tooltip" data-tooltip="Delete"><i class="fa fa-trash"></i></a></li>
                  
                    <!--  <li>
                        <div class="row toggle_btn">
                          <input type="checkbox" id="enable_disable_check_<?=$i?>" data-id="<?=$row['cid']?>" class="cbx hidden enable_disable" <?php if($row['status']==1){ echo 'checked';} ?>>
                          <label for="enable_disable_check_<?=$i?>" class="lbl"></label>
                        </div>
                      </li>-->
                      
                    </ul>
                  </div>
                  
                </div>
              </div>
          <?php
            
            $i++;
              }
        ?>     
               
      </div>
          </div>
          <div class="col-md-12 col-xs-12">
            <div class="pagination_item_block">
              <nav>
                <?php if(!isset($_POST["data_search"])){ include("pagination.php");}?>
              </nav>
            </div>
          </div>
          <div class="clearfix"></div>
        </div>
      </div>
    </div>
	</div>
	
	<div class="custom-section two">
	
		<?php
	 
	 if(isset($_POST['quotes_search']))
     {
    
        
         $quotes_qry="Select * from videotable where category like '%search_value%' ";
        
               
      $result=mysqli_query($mysqli,$quotes_qry);
    
     
   }
   else
   {
      $tableName="videotable";   
      $targetpage = "add_video_templates.php";   
      $limit = 8; 
      
      $query = "SELECT COUNT(*) as num FROM $tableName";
      $total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query));
      $total_pages = $total_pages['num'];
      
      $stages = 3;
      $page=0;
      if(isset($_GET['page'])){
      $page = mysqli_real_escape_string($mysqli,$_GET['page']);
      }
      if($page){
        $start = ($page - 1) * $limit; 
      }else{
        $start = 0; 
        } 
      

                  
                  
                   $quotes_qry = "SELECT * from $tableName ORDER BY id DESC LIMIT $start, $limit";
            
 
     $result=mysqli_query($mysqli,$quotes_qry);

  }
	 
?>
			 <div class="row">
      <div class="col-xs-12">
        <div class="card mrg_bottom">
          <div class="page_title_block">
            <div class="col-md-5 col-xs-12">
              <div class="page_title">Manage Video Template</div>
            </div>
            <div class="col-md-7 col-xs-12">
              <div class="search_list">
           
                <div class="add_btn_primary"> <a href="add_img_quotes.php?add=yes"><i class="fa fa-pencil" aria-hidden="true"></i></a> </div>
              </div>
            </div>
            <div class="col-md-5 col-xs-12" style="margin-bottom: -10px;margin-top: -50px;">
              <div class="page_title">
                 

              </div>

            </div>

          </div>
          <div class="clearfix"></div>
          <div class="row mrg-top">
            <div class="col-md-12">
               
              <div class="col-md-12 col-sm-12">

                <?php if(isset($_SESSION['msg'])){?> 
                 <div class="alert alert-success alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                  <?php echo $client_lang[$_SESSION['msg']] ; ?></a> </div>
                <?php unset($_SESSION['msg']);}?> 
              </div>
            </div>
          </div>

          <div class="col-md-12 mrg-top">
            <div class="row">
              <?php 
            $i=0;
            while($row=mysqli_fetch_array($result))
            {         
        ?>
              <div class="col-lg-12 col-sm-12 col-xs-12">
                <div class="block_wallpaper">
					<span><img src="<?php echo $row['video_thumb']; ?>" /></span>
                  <div class="wall_category_block">
                    <h2><?php echo $row['category'];?></h2>
                    <span><?php echo $row['title'];?></span>    
                  </div>
                  <div class="wall_image_title">
                 
                    <ul> 
                      <li><a href="" data-id="<?php echo $row['id'];?>" data-toggle="tooltip" data-tooltip="Delete" class="btn_delete"><i class="fa fa-trash"></i></a></li>
 
                     
                    </ul>
                  </div>
                  
                </div>
              </div>
           <?php
            
            $i++;
              }
        ?>     
      </div>
          </div>
          <div class="col-md-12 col-xs-12">
            <div class="pagination_item_block">
              <nav>
                <?php if(!isset($_POST["data_search"])){ include("pagination.php");}?>
              </nav>
            </div>
          </div>
          <div class="clearfix"></div>
        </div>
      </div>
    </div>
	 </div>
	
	
		</div>
	</div>

<style>
    
    .value1{
        
        font-size:30px;
        color:white;
        
    }
    .value1:hover {
        
        color:red;
         animation-duration: 0s;
    }
    .contant1{
        height:500px;
    }
</style>     
<?php include("includes/footer.php");?>       
<script type="text/javascript">

  $(".toggle_btn a, .toggle_btn_a").on("click",function(e){
    e.preventDefault();
    
    var _for=$(this).data("action");
    var _id=$(this).data("id");
    var _column=$(this).data("column");
    var _table=$tableName;

    $.ajax({
      type:'post',
      url:'processData.php',
      dataType:'json',
      data:{id:_id,for_action:_for,column:_column,table:_table,'action':'toggle_status','tbl_id':'id'},
      success:function(res){
          console.log(res);
          if(res.status=='1'){
            location.reload();
          }
        }
    });

  });

  $(".btn_delete").click(function(e){
    
    e.preventDefault();
    if(confirm("Are you sure to delete this img quotes?")){
      var _id=$(this).data("id");
      var _table='videotable';

      $.ajax({
        type:'post',
        url:'processData.php',
        dataType:'json',
        data:{id:_id,table:_table,'action':'delete_quote'},
        success:function(res){
            console.log(res);
            if(res.status=='1'){
              location.reload();
            }
          }
      });
    }

  });

  $("button[name='delete_rec']").click(function(e){
      e.preventDefault();

      var _ids = $.map($('.post_ids:checked'), function(c){return c.value; });

      if(_ids!='')
      {
        if(confirm("Are you sure you want to delete this quotes?")){
          $.ajax({
            type:'post',
            url:'processData.php',
            dataType:'json',
            data:{id:_ids,'action':'multi_delete'},
            success:function(res){
                console.log(res);
                if(res.status=='1'){
                  location.reload();
                }
                else if(res.status=='-2'){
                  alert(res.message);
                }
              }
          });
        }
      }
      else{
        alert("No quotes selected");
      }
  });

</script>
<script type="text/javascript">
  $(".enable_disable").on("click",function(e){
    var _for=$(this).prop("checked");
    if(_for==false){
      _for='deactive';
    }else{
      _for='active';
    }
    var _id=$(this).data("id");
    var _column='status';
    var _table='$tname';

    $.ajax({
      type:'post',
      url:'processData.php',
      dataType:'json',
      data:{id:_id,for_action:_for,column:_column,table:_table,'action':'toggle_status','tbl_id':'cid'},
      success:function(res){
          if(res.status=='1'){
            $('.notifyjs-corner').empty();
            $.notify(
              res.msg, 
              { position:"top right",className: 'success' }
            );
          }
        }
    });

  });
</script>   
