<?php
require_once("configuration.php");
$input = @file_get_contents("php://input");
// $event_json = json_decode($input, true);
// $event_json = $_POST['cat'];
// $query = 'query';
// if(isset($event_json['app']))


$array_out = array();


// echo "<script>console.log('Debug Objects: " . "{$_POST['cat']}" . "' );</script>";

if ($_POST['cat'] == 'Latest') {
	$query = mysqli_query($conn, "SELECT * FROM `videotable` ORDER BY rand()");
} else if ($_POST['cat'] == 'Popular') {
	// echo "<script>console.log('Debug Objects: " . "cat" . "' );</script>";

	$query = mysqli_query($conn, "SELECT * FROM `videotable` ORDER BY `videotable`.`downloads` DESC");
	// print_r(json_encode($query));
	// echo $query;
} else {
	$query = mysqli_query($conn, "SELECT * FROM `videotable` WHERE category ='" . $_POST['cat'] . "' ORDER BY id DESC");
}
while ($row = mysqli_fetch_array($query)) {
	$array_out[] =
		array(
			"id" => $row['id'],
			"title" => $row['title'],
			"video_thumb" => $dirname . "/" . $row['video_thumb'],
			"video_link" => $dirname . "/" . $row['video_link'],
			"video_zip" => $dirname . "/" . $row['video_zip']

		);
}

$output = array("code" => "200", "msg" => $array_out);
print_r(json_encode($output, true));
