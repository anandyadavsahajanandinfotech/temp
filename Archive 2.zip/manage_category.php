<?php include("includes/header.php");

	require("includes/function.php");
	require("language/language.php");
	
	
	$tname ="category";

  if(isset($_POST['data_search']))
   {

      $qry="SELECT * FROM $tname                   
                  WHERE `category` LIKE '%".addslashes($_POST['search_value'])."%'
                  ORDER BY `category`";
 
     $result=mysqli_query($mysqli,$qry); 

   }
   else
   {
	
	//Get all Category 
	 
      $tableName="category";   
      $targetpage = "manage_category.php"; 
      $limit = 12; 
      
      $query = "SELECT COUNT(*) as num FROM $tableName";
      $total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query));
      $total_pages = $total_pages['num'];
      
      $stages = 3;
      $page=0;
      if(isset($_GET['page'])){
      $page = mysqli_real_escape_string($mysqli,$_GET['page']);
      }
      if($page){
        $start = ($page - 1) * $limit; 
      }else{
        $start = 0; 
        } 
      
     $qry="SELECT * FROM $tableName
                   ORDER BY category DESC LIMIT $start, $limit";
 
     $result=mysqli_query($mysqli,$qry); 
	
    } 

	if(isset($_GET['cat_id']))
	{ 

    Delete($tname,'id='.$_GET['cat_id'].'');
		
		$cat_res=mysqli_query($mysqli,'SELECT * FROM $tname WHERE id=\''.$_GET['id'].'\'');
    echo($cat_res);
		$cat_res_row=mysqli_fetch_assoc($cat_res);

		if($cat_res_row['category_image']!="")
	    {
	    	unlink('images/'.$cat_res_row['category_image']);
			  unlink('images/thumbs/'.$cat_res_row['category_image']);
		}
 
		Delete($tname,'id='.$_GET['id'].'');

		$_SESSION['msg']="12";
		header( "Location:manage_category.php");
		exit;
		
	}	

   
  //Active and Deactive status
if(isset($_GET['status_deactive_id']))
{
   $data = array('status'  =>  '0');
  
   $edit_status=Update($tname, $data, "WHERE cid = '".$_GET['status_deactive_id']."'");
  
   $_SESSION['msg']="14";
   header( "Location:manage_category.php");
   exit;
}
if(isset($_GET['status_active_id']))
{
    $data = array('status'  =>  '1');
    
    $edit_status=Update('$tname', $data, "WHERE cid = '".$_GET['status_active_id']."'");
    
    $_SESSION['msg']="13";   
    header( "Location:manage_category.php");
    exit;
}  
	 
?>
                
    <div class="row">
      <div class="col-xs-12">
        <div class="card mrg_bottom">
          <div class="page_title_block">
            <div class="col-md-5 col-xs-12">
              <div class="page_title">Manage Categories</div>
            </div>
            <div class="col-md-7 col-xs-12">
              <div class="search_list">
                <div class="search_block">
                  <form  method="post" action="">
                  <input class="form-control input-sm" placeholder="Search..." aria-controls="DataTables_Table_0" type="search" name="search_value" required>
                        <button type="submit" name="data_search" class="btn-search"><i class="fa fa-search"></i></button>
                  </form>  
                </div>
                <div class="add_btn_primary"> <a href="add_category.php?add=yes"><i class="fa fa-pencil" aria-hidden="true"></i></a> </div>
              </div>
            </div>
          </div>
           <div class="clearfix"></div>
          <div class="row mrg-top">
            <div class="col-md-12">
               
              <div class="col-md-12 col-sm-12">
                <?php if(isset($_SESSION['msg'])){?> 
                 <div class="alert alert-success alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                  <?php echo $client_lang[$_SESSION['msg']] ; ?></a> </div>
                <?php unset($_SESSION['msg']);}?> 
              </div>
            </div>
          </div>
          <div class="col-md-12 mrg-top">
            <div class="row">
              <?php 
              $i=0;
              while($row=mysqli_fetch_array($result))
              {         
          ?>
              <div class="col-lg-12 col-sm-12 col-xs-12">
                <div class="block_wallpaper add_wall_category">
					<span><img src="<?php echo $row['image'];?>" /></span>
					<div class="wall_category_block">
                    <h2><?php echo $row['category'];?></h2>
                    <span><?php echo $row['title'];?></span>    
                  </div>
                  <div class="wall_image_title">
                    
                    <ul>                
                                
                      <li><a href="?cat_id=<?php echo $row['id'];?>" data-toggle="tooltip" data-tooltip="Delete"><i class="fa fa-trash"></i></a></li>
                  
                  
                      
                    </ul>
                  </div>
                  
                </div>
              </div>
          <?php
            
            $i++;
              }
        ?>     
               
      </div>
          </div>
          <div class="col-md-12 col-xs-12">
            <div class="pagination_item_block">
              <nav>
                <?php if(!isset($_POST["data_search"])){ include("pagination.php");}?>
              </nav>
            </div>
          </div>
          <div class="clearfix"></div>
        </div>
      </div>
    </div>
        
<?php include("includes/footer.php");?>  

<script type="text/javascript"></script>  

<script type="text/javascript">
  $(".enable_disable").on("click",function(e){
    var _for=$(this).prop("checked");
    if(_for==false){
      _for='deactive';
    }else{
      _for='active';
    }
    var _id=$(this).data("id");
    var _column='status';
    var _table='$tname';

    $.ajax({
      type:'post',
      url:'processData.php',
      dataType:'json',
      data:{id:_id,for_action:_for,column:_column,table:_table,'action':'toggle_status','tbl_id':'cid'},
      success:function(res){
          if(res.status=='1'){
            $('.notifyjs-corner').empty();
            $.notify(
              res.msg, 
              { position:"top right",className: 'success' }
            );
          }
        }
    });

  });
</script>   
