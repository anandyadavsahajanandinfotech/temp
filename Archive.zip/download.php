<?php
require_once("configuration.php");
$input = @file_get_contents("php://input");
$event_json = json_decode($input, true);
$query = 'query';
// if(isset($event_json['app']))

$array_out = array();
$query = mysqli_query($conn, "UPDATE `videotable` SET `downloads`=downloads+1 WHERE id='" . $_POST['id'] . "'");
$output = array("code" => "200", "msg" => "Success");
print_r(json_encode($output, true));
