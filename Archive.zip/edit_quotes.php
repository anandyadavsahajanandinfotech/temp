<?php include("includes/header.php");

	require("includes/function.php");
	require("language/language.php");

	require_once("thumbnail_images.class.php");
	
	 
	$cat_qry="SELECT * FROM tbl_category ORDER BY category_name";
	$cat_result=mysqli_query($mysqli,$cat_qry);
 

  if(isset($_GET['quotes_id']))
  {
    $quote_qry="SELECT * FROM  tbl_quotes WHERE id='".$_GET['quotes_id']."'";
    $quote_res=mysqli_query($mysqli,$quote_qry);
    $quote_row=mysqli_fetch_assoc($quote_res);
     
     
  }
	 	
	if(isset($_POST['submit']) and isset($_POST['quotes_id']))
	{	 
 
     $data = array( 
          'cat_id'  =>  $_POST['cat_id'],
           'quote'  =>  addslashes($_POST['quote']) 
          );    

     $quotes_edit=Update('tbl_quotes', $data, "WHERE id = '".$_POST['quotes_id']."'");
      
      $_SESSION['msg']="11"; 
      header("Location:edit_quotes.php?quotes_id=".$_POST['quotes_id']);
      exit;
 
	}	
	 
?>
 
       <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="page_title_block">
            <div class="col-md-5 col-xs-12">
              <div class="page_title">Edit Quotes</div>
            </div>
          </div>
          <div class="clearfix"></div>
          <div class="row mrg-top">
            <div class="col-md-12">
               
              <div class="col-md-12 col-sm-12">
                <?php if(isset($_SESSION['msg'])){?> 
                 <div class="alert alert-success alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                  <?php echo $client_lang[$_SESSION['msg']] ; ?></a> </div>
                <?php unset($_SESSION['msg']);}?> 
              </div>
            </div>
          </div>
          <div class="card-body mrg_bottom">
            <form class="form form-horizontal" action="" method="post"  enctype="multipart/form-data">
              
              <input  type="hidden" name="quotes_id" value="<?php echo $_GET['quotes_id'];?>" />

              <div class="section">
                <div class="section-body">
                  <div class="form-group">
                    <label class="col-md-3 control-label">Category :-</label>
                    <div class="col-md-6">
                      <select name="cat_id" id="cat_id" class="select2">
                        <option value="">--Select Category--</option>
          							<?php
          									while($cat_row=mysqli_fetch_array($cat_result))
          									{
          							?>          						 
          							  <option value="<?php echo $cat_row['cid'];?>" <?php if($cat_row['cid']==$quote_row['cat_id']){?>selected<?php }?>><?php echo $cat_row['category_name'];?></option>	          							 
          							<?php
          								}
          							?>
                      </select>
                    </div>
                  </div>
                   
                  <div class="form-group">
                    <div class="col-md-3">
                      <label class="control-label">Quote :-</label>
                    </div>
                    <div class="col-md-6">
                      <textarea name="quote" id="quote" rows="5" class="form-control"><?php echo $quote_row['quote'];?></textarea>
                        
                    </div>
                  </div>
                   
                   
                  <div class="form-group">&nbsp;</div>
                  <div class="form-group">
                    <div class="col-md-9 col-md-offset-3">
                      <button type="submit" name="submit" class="btn btn-primary">Save</button>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>           
                 
        
<?php include("includes/footer.php");?>       
