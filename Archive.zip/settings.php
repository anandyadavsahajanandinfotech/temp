<?php include("includes/header.php");

	require("includes/function.php");
	require("language/language.php");
	 
	
  $qry="SELECT * FROM tbl_settings where id='1'";
  $result=mysqli_query($mysqli,$qry);
  $settings_row=mysqli_fetch_assoc($result);

 
  if(isset($_POST['current_tab'])){
    $current_tab=str_replace('#', '', $_POST['current_tab']);
  }
   
  if(isset($_POST['submit']))
  {
    
    $img_res=mysqli_query($mysqli,"SELECT * FROM tbl_settings WHERE id='1'");
    $img_row=mysqli_fetch_assoc($img_res);
    

    if($_FILES['app_logo']['name']!="")
    {        

            unlink('images/'.$img_row['app_logo']);   

            $app_logo=$_FILES['app_logo']['name'];
            $pic1=$_FILES['app_logo']['tmp_name'];

            $tpath1='images/'.$app_logo;      
            copy($pic1,$tpath1);


              $data = array(
              'email_from'  =>  $_POST['email_from'],  
              'app_name'  =>  $_POST['app_name'],
              'app_logo'  =>  $app_logo,  
              'app_description'  => addslashes($_POST['app_description']),
              'app_version'  =>  $_POST['app_version'],
              'app_author'  =>  $_POST['app_author'],
              'app_contact'  =>  $_POST['app_contact'],
              'app_email'  =>  $_POST['app_email'],   
              'app_website'  =>  $_POST['app_website'],
              'app_developed_by'  =>  $_POST['app_developed_by']                     

              );

    }
    else
    {
  
                $data = array(
                'email_from'  =>  $_POST['email_from'],  
                'app_name'  =>  $_POST['app_name'],
                'app_description'  => addslashes($_POST['app_description']),
                'app_version'  =>  $_POST['app_version'],
                'app_author'  =>  $_POST['app_author'],
                'app_contact'  =>  $_POST['app_contact'],
                'app_email'  =>  $_POST['app_email'],   
                'app_website'  =>  $_POST['app_website'],
                'app_developed_by'  =>  $_POST['app_developed_by']              

                  );

    } 

    $settings_edit=Update('tbl_settings', $data, "WHERE id = '1'");
  
        $_SESSION['msg']="11";
        header( "Location:settings.php?active=".$current_tab);
        exit;
   
 
  }
  if(isset($_POST['verify_purchase_submit']))
  {
            $data = array(
                  'envato_buyer_name' => $_POST['envato_buyer_name'],
                  'envato_purchase_code' => $_POST['envato_purchase_code'],
                  'envato_buyer_email' => $_POST['envato_buyer_email'],
                  'envato_purchased_status' => 1,
                  'package_name' => $_POST['package_name']
                    );
      
           $settings_edit=Update('tbl_settings', $data, "WHERE id = '1'");

            
            $config_file_default    = "includes/app.default";
            $config_file_name       = "api.php";    

            $config_file_path       = $config_file_name;

            $config_file = file_get_contents($config_file_default);
            //$config_file = str_replace("NEWS_APP", 'NEWS_APP_DEMO', $config_file);

            $f = @fopen($config_file_path, "w+");
            
            if(@fwrite($f, $config_file) > 0){

              echo "done";

            }
            $_SESSION['msg']="19";
            header( "Location:settings.php?active=".$current_tab);
            exit;
  }

  if(isset($_POST['admob_submit']))
  {

        $data = array(
                'publisher_id'  =>  $_POST['publisher_id'],
                'interstital_ad'  =>  $_POST['interstital_ad'],
                'interstital_ad_id'  =>  $_POST['interstital_ad_id'],
                'interstital_ad_click'  =>  $_POST['interstital_ad_click'],
                'banner_ad'  =>  $_POST['banner_ad'],
                'banner_ad_id'  =>  $_POST['banner_ad_id']                
                
                  );

    
      $settings_edit=Update('tbl_settings', $data, "WHERE id = '1'");
  
      
        $_SESSION['msg']="11";
    	header( "Location:settings.php?active=".$current_tab);
        exit;
 
 
  }

  if(isset($_POST['notification_submit']))
  {

        $data = array(
                'onesignal_app_id' => $_POST['onesignal_app_id'],
                'onesignal_rest_key' => $_POST['onesignal_rest_key'],
                  );

    
      $settings_edit=Update('tbl_settings', $data, "WHERE id = '1'");
  
 
        $_SESSION['msg']="11";
   	    header( "Location:settings.php?active=".$current_tab);
        exit;
 
  }


  if(isset($_POST['api_submit']))
  {

        $data = array(                
                'api_home_limit'  =>  $_POST['api_home_limit'],
                'api_latest_limit'  =>  $_POST['api_latest_limit'],
                'api_cat_order_by'  =>  $_POST['api_cat_order_by'] 
                   );

    
      $settings_edit=Update('tbl_settings', $data, "WHERE id = '1'");
 

      if ($settings_edit > 0)
      {

        $_SESSION['msg']="11";
   	    header( "Location:settings.php?active=".$current_tab);
        exit;

      }   
 
  }

  if(isset($_POST['app_pri_poly']))
  {

        $data = array(
                'app_privacy_policy'  =>  addslashes($_POST['app_privacy_policy']) 
                  );

    
      $settings_edit=Update('tbl_settings', $data, "WHERE id = '1'");
 

      if ($settings_edit > 0)
      {

        $_SESSION['msg']="11";
    	header( "Location:settings.php?active=".$current_tab);
        exit;

      }   
 
  }


?>
 <script src="assets/ckeditor/ckeditor.js"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

	 <div class="row">
      <div class="col-md-12">
        <div class="card">
		  <div class="page_title_block">
            <div class="col-md-5 col-xs-12">
              <div class="page_title">Settings</div>
            </div>
          </div>
          <div class="clearfix"></div>
          <div class="row mrg-top">
            <div class="col-md-12">
               
              <div class="col-md-12 col-sm-12">
                <?php if(isset($_SESSION['msg'])){?> 
                 <div class="alert alert-success alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                  <?php echo $client_lang[$_SESSION['msg']] ; ?></a> </div>
                <?php unset($_SESSION['msg']);}?> 
              </div>
            </div>
          </div>
          <div class="card-body mrg_bottom">
            <!-- Nav tabs -->
            <ul class="nav nav-tabs" role="tablist">
                <li role="presentation" class="active"><a href="#notification_settings" aria-controls="notification_settings" role="tab" data-toggle="tab">Notification Settings</a></li>
            </ul>
          
           <div class="tab-content">
              <div role="tabpanel" class="tab-pane" id="notification_settings">
              <form action="" name="settings_api" method="post" class="form form-horizontal" enctype="multipart/form-data" id="api_form">
                <input type="hidden" class="current_tab"   name="current_tab">
			    <div class="section">
                <div class="section-body">
                  <div class="form-group">
                    <label class="col-md-3 control-label">OneSignal App ID :-</label>
                    <div class="col-md-6">
                      <input type="text" name="onesignal_app_id" id="onesignal_app_id" value="<?php echo $settings_row['onesignal_app_id'];?>" class="form-control">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-md-3 control-label">OneSignal Rest Key :-</label>
                    <div class="col-md-6">
                      <input type="text" name="onesignal_rest_key" id="onesignal_rest_key" value="<?php echo $settings_row['onesignal_rest_key'];?>" class="form-control">
                    </div>
                  </div>              
                  <div class="form-group">
                  <div class="col-md-9 col-md-offset-3">
                    <button type="submit" name="notification_submit" class="btn btn-primary">Save</button>
                  </div>
                  </div>
                </div>
                </div>
              </form>
            </div>
            </div>   

          </div>
        </div>
      </div>
    </div>

        
<?php include("includes/footer.php");?>       
<script type="text/javascript">

  $.urlParam = function(name){
      var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
      if (results==null) {
         return null;
      }
      return decodeURI(results[1]) || 0;
  }

  $(document).ready(function(e){
    var getTab=$.urlParam('active');

    if(getTab!=null){
      var current_tab="#"+getTab;
    }else{
      var current_tab=$(".nav-tabs li.active a").attr("href");
    }
    
    $("div").find(".tab-pane").removeClass("active");
    $(".nav-tabs").find("li").removeClass("active");
    $(".current_tab").val(current_tab);
    $("div").find($('.current_tab').val()).addClass("active");

    $(".nav-tabs li").each(function() {
      if($(this).find("a").attr("href")==current_tab){
          $(this).addClass("active");
      }
    });

    $("div").find($('.current_tab').val()).addClass("active");

    $(".nav-tabs li a").on("click",function(e){
        $(".current_tab").val($(this).attr("href"));
        $("div").find($('.current_tab').val()).addClass("active");
    });
  });
  
</script>