<?php

    //database configration
	$servername = "localhost";
	$database = "db";
	$username = "anand";
	$password = "@A1b2c3d4@nand";
    
	// Create connection
    $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    $dirname = dirname($actual_link);

	$conn = mysqli_connect($servername, $username, $password, $database);
	mysqli_query($conn,"SET SESSION sql_mode = 'NO_ENGINE_SUBSTITUTION'");
	
	// Check connection

	if (!$conn) {

	    die("Connection failed: " . mysqli_connect_error());

	}
	else
	{
		//die("file not found");
	}

 ?>