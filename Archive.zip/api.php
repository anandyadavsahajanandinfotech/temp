<?php 
	include("includes/connection.php");
 	include("includes/function.php"); 	
 	include("language/app_language.php"); 	
 	include("smtp_email.php");
	
	date_default_timezone_set("Asia/Kolkata");
	
	$protocol = strtolower( substr( $_SERVER[ 'SERVER_PROTOCOL' ], 0, 5 ) ) == 'https' ? 'https' : 'http'; 

	$file_path = $protocol.'://'.$_SERVER['SERVER_NAME'] . dirname($_SERVER['REQUEST_URI']).'/';

	define("PACKAGE_NAME",$settings_details['package_name']);

	define("HOME_LIMIT",$settings_details['api_home_limit']);
	
	
   mysql_query("SET character_set_client=utf8mb4", $mysqli);
   mysql_query("SET character_set_connection=utf8mb4", $mysqli);
  mysql_query("SET character_set_results=utf8mb4", $mysqli);

	function get_thumb($filename,$thumb_size)
	{	
		$file_path = 'http://'.$_SERVER['SERVER_NAME'] . dirname($_SERVER['REQUEST_URI']).'/';

		return $thumb_path=$file_path.'thumb.php?src='.$filename.'&size='.$thumb_size;
	}

  
  	$get_method = checkSignSalt($_POST['data']);
   
  	if($get_method['method_name']=="get_home")	
   	{ 
 		$jsonObj_1= array();

		$query_1="SELECT * FROM tbl_img_quotes
                  LEFT JOIN tbl_category ON tbl_img_quotes.`cat_id`= tbl_category.`cid` 
                  WHERE tbl_img_quotes.`status`='1' AND tbl_img_quotes.`featured`='1' AND tbl_category.`status`='1' ORDER BY tbl_img_quotes.`id` DESC LIMIT ".HOME_LIMIT;

		$sql_1 = mysqli_query($mysqli,$query_1)or die(mysqli_error());

		while($data_1 = mysqli_fetch_assoc($sql_1))
		{
			$row_1['id'] = $data_1['id'];
			$row_1['cat_id'] = $data_1['cat_id'];		  
  		 	
		 	$row_1['quote_image_b'] = $file_path.'images/'.$data_1['quote_image'];
		    $row_1['quote_image_s'] = get_thumb('images/'.$data_1['quote_image'],'300x300');
			
			$row_1['quotes_likes'] = $data_1['quotes_likes'];
			$row_1['total_views'] = $data_1['total_views'];
			$row_1['total_download'] = $data_1['total_download'];  

			    $query_like = mysqli_query($mysqli,"select * from tbl_img_like where quotes_id='".$data_1['id']."' && device_id='".$get_method['device_id']."' "); 
    			$num_rows1 = mysqli_num_rows($query_like);
 		
            if ($num_rows1 > 0)
		    {
    			$row_1['already_like']=true;
    		}
    		else
    		{
    			$row_1['already_like']=false;
    		}
   		 
			array_push($jsonObj_1,$row_1);
		
		}

		$row['featured_image_quotes']=$jsonObj_1;


		$latest_limit=API_LATEST_LIMIT;

		$jsonObj_2= array();

		$query_2="SELECT * FROM tbl_img_quotes
                  LEFT JOIN tbl_category ON tbl_img_quotes.`cat_id`= tbl_category.`cid` 
                  WHERE tbl_img_quotes.`status`='1' AND tbl_category.`status`='1' ORDER BY tbl_img_quotes.`id` DESC LIMIT ".HOME_LIMIT;

		$sql_2 = mysqli_query($mysqli,$query_2)or die(mysqli_error());

		while($data_2 = mysqli_fetch_assoc($sql_2))
		{
			$row_2['id'] = $data_2['id'];
			$row_2['cat_id'] = $data_2['cat_id'];		  
  		 	$row_2['quote_image_b'] = $file_path.'images/'.$data_2['quote_image'];
		    $row_2['quote_image_s'] = get_thumb('images/'.$data_2['quote_image'],'300x300');

  		 	$row_2['quotes_likes'] = $data_2['quotes_likes'];
			$row_2['total_views'] = $data_2['total_views'];
			$row_2['total_download'] = $data_2['total_download'];

			$query_like = mysqli_query($mysqli,"select * from tbl_img_like where quotes_id='".$data_2['id']."' && device_id='".$get_method['device_id']."' "); 
    			$num_rows1 = mysqli_num_rows($query_like);
 		
            if ($num_rows1 > 0)
		    {
    			$row_2['already_like']=true;
    		}
    		else
    		{
    			$row_2['already_like']=false;
    		}
   		 
			array_push($jsonObj_2,$row_2);
		
		}

		$row['latest_image_quotes']=$jsonObj_2;

		$jsonObj_3= array();

		$query_3="SELECT * FROM tbl_img_quotes
                  LEFT JOIN tbl_category ON tbl_img_quotes.`cat_id`= tbl_category.`cid` 
                  WHERE tbl_img_quotes.`status`='1' AND tbl_category.`status`='1' ORDER BY tbl_img_quotes.`total_views` DESC LIMIT ".HOME_LIMIT;

		$sql_3 = mysqli_query($mysqli,$query_3)or die(mysqli_error());

		while($data_3 = mysqli_fetch_assoc($sql_3))
		{
			$row_3['id'] = $data_3['id'];
			$row_3['cat_id'] = $data_3['cat_id'];		  
  		 	$row_3['quote_image_b'] = $file_path.'images/'.$data_3['quote_image'];
		    $row_3['quote_image_s'] = get_thumb('images/'.$data_3['quote_image'],'300x300');

  		 	$row_3['quotes_likes'] = $data_3['quotes_likes'];
			$row_3['total_views'] = $data_3['total_views'];
			$row_3['total_download'] = $data_3['total_download'];

			$query_like = mysqli_query($mysqli,"select * from tbl_img_like where quotes_id='".$data_3['id']."' && device_id='".$get_method['device_id']."' "); 
    			$num_rows1 = mysqli_num_rows($query_like);
 		
            if ($num_rows1 > 0)
		    {
    			$row_3['already_like']=true;
    		}
    		else
    		{
    			$row_3['already_like']=false;
    		}
   		 
			array_push($jsonObj_3,$row_3);
		
		}

		$row['popular_image_quotes']=$jsonObj_3;


		$jsonObj_4= array();

		$query_4="SELECT * FROM tbl_img_quotes
                  LEFT JOIN tbl_category ON tbl_img_quotes.`cat_id`= tbl_category.`cid` 
                  WHERE tbl_img_quotes.`status`='1' AND tbl_category.`status`='1' ORDER BY tbl_img_quotes.`quotes_likes` DESC LIMIT ".HOME_LIMIT;

		$sql_4 = mysqli_query($mysqli,$query_4)or die(mysqli_error());

		while($data_4 = mysqli_fetch_assoc($sql_4))
		{

			$row_4['id'] = $data_4['id'];
			$row_4['cat_id'] = $data_4['cat_id'];		  
  		 	$row_4['quote_image_b'] = $file_path.'images/'.$data_4['quote_image'];
		    $row_4['quote_image_s'] = get_thumb('images/'.$data_4['quote_image'],'300x300');

  		 	$row_4['quotes_likes'] = $data_4['quotes_likes'];
			$row_4['total_views'] = $data_4['total_views'];
			$row_4['total_download'] = $data_4['total_download'];

			$query_like = mysqli_query($mysqli,"select * from tbl_img_like where quotes_id='".$data_4['id']."' && device_id='".$get_method['device_id']."' "); 
    			$num_rows1 = mysqli_num_rows($query_like);
 		
            if ($num_rows1 > 0)
		    {
    			$row_4['already_like']=true;
    		}
    		else
    		{
    			$row_4['already_like']=false;
    		}
   		 
			array_push($jsonObj_4,$row_4);
		
		}

		$row['top_liked_image_quotes']=$jsonObj_4;

		$jsonObj_5= array();	
	
	    $query5="SELECT * FROM tbl_quotes
			LEFT JOIN tbl_category ON tbl_quotes.`cat_id`= tbl_category.`cid` 
			WHERE tbl_quotes.`status`='1' AND tbl_category.`status`='1' ORDER BY tbl_quotes.`id` DESC LIMIT ".HOME_LIMIT;

		$sql_5 = mysqli_query($mysqli,$query5)or die(mysqli_error());

		while($data_5 = mysqli_fetch_assoc($sql_5))
		{
			$row_5['id'] = $data_5['id'];
			$row_5['cat_id'] = $data_5['cat_id'];		  
  		 	$row_5['quote'] = $data_5['quote'];	 

  		 	$row_5['quotes_likes'] = $data_5['quotes_likes'];
 			$row_5['total_views'] = $data_5['total_views'];
			$row_5['total_download'] = $data_5['total_download'];

			$query_like = mysqli_query($mysqli,"select * from tbl_like where quotes_id='".$data_5['id']."' && device_id='".$get_method['device_id']."' "); 
    			$num_rows1 = mysqli_num_rows($query_like);
 		
            if ($num_rows1 > 0)
		    {
    			$row_5['already_like']=true;
    		}
    		else
    		{
    			$row_5['already_like']=false;
    		}

			$row_5['cid'] = $data_5['cid'];
			$row_5['category_name'] = $data_5['category_name'];
			$row_5['category_image'] = $file_path.'images/'.$data_5['category_image'];
			$row_5['category_image_thumb'] = get_thumb('images/'.$data_5['category_image'],'300x300');
			 

			array_push($jsonObj_5,$row_5);
		
		}

		$row['latest_text_quotes']=$jsonObj_5;

		$set['QUOTES_DIARY'] = $row;

		header( 'Content-Type: application/json' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();

	}
  	else if($get_method['method_name']=="search_text_quotes")	
 	{ 
		
		$data_limit=API_LATEST_LIMIT;

 		$limit=($get_method['page']-1) * $data_limit;
 		
 		$query_rec = "SELECT COUNT(*) as num FROM tbl_quotes
			LEFT JOIN tbl_category ON tbl_quotes.`cat_id`= tbl_category.`cid` 
        	WHERE tbl_quotes.`status`='1' AND tbl_category.`status`='1' AND tbl_quotes.`quote` LIKE '%".$get_method['search_text_quotes']."%'";

		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query_rec));


		$jsonObj_2= array();

		$query_2="SELECT * FROM tbl_quotes
                  LEFT JOIN tbl_category ON tbl_quotes.`cat_id`= tbl_category.`cid` 
                  WHERE tbl_quotes.`status`='1' AND tbl_category.`status`='1' AND tbl_quotes.`quote` LIKE '%".$get_method['search_text_quotes']."%' ORDER BY tbl_quotes.id DESC LIMIT $limit, $data_limit";

		$sql_2 = mysqli_query($mysqli,$query_2)or die(mysqli_error());

		while($data_2 = mysqli_fetch_assoc($sql_2))
		{
			$row_2['num'] = $total_pages['num'];
			$row_2['id'] = $data_2['id'];
			$row_2['cat_id'] = $data_2['cat_id'];		  
  		 	$row_2['quote'] = stripslashes($data_2['quote']);

  		 	$row_2['quotes_likes'] = $data_2['quotes_likes'];
			$row_2['total_views'] = $data_2['total_views'];
			$row_2['total_download'] = $data_2['total_download'];

			$query_like = mysqli_query($mysqli,"select * from tbl_like where quotes_id='".$data_2['id']."' && device_id='".$get_method['device_id']."' "); 
    			$num_rows1 = mysqli_num_rows($query_like);
 		
            if ($num_rows1 > 0)
		    {
    			$row_2['already_like']=true;
    		}
    		else
    		{
    			$row_2['already_like']=false;
    		}
   		 
			array_push($jsonObj_2,$row_2);
		
		}
 
 
		$set['QUOTES_DIARY'] = $jsonObj_2;

		header( 'Content-Type: application/json' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();

	}
	else  if($get_method['method_name']=="search_image_quotes")	
 	{ 	

 		$data_limit=API_LATEST_LIMIT;

 		$limit=($get_method['page']-1) * $data_limit;
 		$query_rec = "SELECT COUNT(*) as num FROM tbl_img_quotes
                  LEFT JOIN tbl_category ON tbl_img_quotes.`cat_id`= tbl_category.`cid` 
                  WHERE tbl_img_quotes.`status`='1' AND tbl_category.`status`='1' AND tbl_category.`category_name` LIKE '%".$get_method['search_image_quotes']."%'";
		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query_rec));


 		$jsonObj_1= array();

		$query_1="SELECT * FROM tbl_img_quotes
                  LEFT JOIN tbl_category ON tbl_img_quotes.`cat_id`= tbl_category.`cid` 
                  WHERE tbl_img_quotes.`status`='1' AND tbl_category.`status`='1' AND tbl_category.`category_name` LIKE '%".$get_method['search_image_quotes']."%' ORDER BY tbl_img_quotes.`id` DESC LIMIT $limit, $data_limit";

		$sql_1 = mysqli_query($mysqli,$query_1)or die(mysqli_error());

		while($data_1 = mysqli_fetch_assoc($sql_1))
		{	
			$row_1['num'] = $total_pages['num'];
			$row_1['id'] = $data_1['id'];
			$row_1['cat_id'] = $data_1['cat_id'];		  
  		 	
		 	$row_1['quote_image_b'] = $file_path.'images/'.$data_1['quote_image'];
		    $row_1['quote_image_s'] = get_thumb('images/'.$data_1['quote_image'],'300x300');
			
			$row_1['quotes_likes'] = $data_1['quotes_likes'];
			$row_1['total_views'] = $data_1['total_views'];
			$row_1['total_download'] = $data_1['total_download'];  

			$query_like = mysqli_query($mysqli,"select * from tbl_img_like where quotes_id='".$data_1['id']."' && device_id='".$get_method['device_id']."' "); 
    			$num_rows1 = mysqli_num_rows($query_like);
 		
            if ($num_rows1 > 0)
		    {
    			$row_1['already_like']=true;
    		}
    		else
    		{
    			$row_1['already_like']=false;
    		}
   		 
			array_push($jsonObj_1,$row_1);
		
		}	  
 
		$set['QUOTES_DIARY'] = $jsonObj_1;

		header( 'Content-Type: application/json' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();

	}	
	else  if($get_method['method_name']=="text_quotes_latest")	
	{
		 
 		$data_limit=API_LATEST_LIMIT;

 		$limit=($get_method['page']-1) * $data_limit;
 		
 		$query_rec = "SELECT COUNT(*) as num FROM tbl_quotes
			LEFT JOIN tbl_category ON tbl_quotes.`cat_id`= tbl_category.`cid` 
			WHERE tbl_quotes.`status`='1' AND tbl_category.`status`='1'";

		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query_rec));

		$jsonObj= array();	
	
	    $query="SELECT * FROM tbl_quotes
		LEFT JOIN tbl_category ON tbl_quotes.`cat_id`= tbl_category.`cid` 
		WHERE tbl_quotes.`status`='1' AND tbl_category.`status`='1' ORDER BY tbl_quotes.`id` DESC LIMIT $limit, $data_limit";

		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			$row['num'] = $total_pages['num'];
			$row['id'] = $data['id'];
			$row['cat_id'] = $data['cat_id'];		  
  		 	$row['quote'] = stripslashes($data['quote']);	 

  		 	$row['quotes_likes'] = $data['quotes_likes'];
 			$row['total_views'] = $data['total_views'];
			$row['total_download'] = $data['total_download'];

			$query_like = mysqli_query($mysqli,"select * from tbl_like where quotes_id='".$data['id']."' && device_id='".$get_method['device_id']."' "); 
    			$num_rows1 = mysqli_num_rows($query_like);
 		
            if ($num_rows1 > 0)
		    {
    			$row['already_like']=true;
    		}
    		else
    		{
    			$row['already_like']=false;
    		}

			$row['cid'] = $data['cid'];
			$row['category_name'] = $data['category_name'];
			$row['category_image'] = $file_path.'images/'.$data['category_image'];
			$row['category_image_thumb'] = get_thumb('images/'.$data['category_image'],'300x300');
			 

			array_push($jsonObj,$row);
		
		}

		$set['QUOTES_DIARY'] = $jsonObj;
		
		header( 'Content-Type: application/json' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();

		
	}
	else  if($get_method['method_name']=="image_quotes_latest")	
	{
		 
 		$data_limit=API_LATEST_LIMIT;

 		$limit=($get_method['page']-1) * $data_limit;
 		$query_rec = "SELECT COUNT(*) as num FROM tbl_img_quotes
			LEFT JOIN tbl_category ON tbl_img_quotes.`cat_id`= tbl_category.`cid` 
			WHERE tbl_img_quotes.`status`='1' AND tbl_category.`status`='1'";
		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query_rec));

		$jsonObj= array();	
	
	    $query="SELECT * FROM tbl_img_quotes
			LEFT JOIN tbl_category ON tbl_img_quotes.`cat_id`= tbl_category.`cid` 
			WHERE tbl_img_quotes.`status`='1' AND tbl_category.`status`='1' ORDER BY tbl_img_quotes.`id` DESC LIMIT $limit, $data_limit";

		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			$row['num'] = $total_pages['num'];
			$row['id'] = $data['id'];
			$row['cat_id'] = $data['cat_id'];		  
  		 	$row['quote_image_b'] = $file_path.'images/'.$data['quote_image'];
		    $row['quote_image_s'] = get_thumb('images/'.$data['quote_image'],'300x300');

		    $row['quotes_likes'] = $data['quotes_likes'];
 			$row['total_views'] = $data['total_views'];
			$row['total_download'] = $data['total_download'];

			$query_like = mysqli_query($mysqli,"select * from tbl_img_like where quotes_id='".$data['id']."' && device_id='".$get_method['device_id']."' "); 
    			$num_rows1 = mysqli_num_rows($query_like);
 		
            if ($num_rows1 > 0)
		    {
    			$row['already_like']=true;
    		}
    		else
    		{
    			$row['already_like']=false;
    		}

			$row['cid'] = $data['cid'];
			$row['category_name'] = $data['category_name'];
			$row['category_image'] = $file_path.'images/'.$data['category_image'];
			$row['category_image_thumb'] = get_thumb('images/'.$data['category_image'],'300x300');
			 

			array_push($jsonObj,$row);
		
		}

		$set['QUOTES_DIARY'] = $jsonObj;
		
		header( 'Content-Type: application/json' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();
		
	}
	else  if($get_method['method_name']=="get_cat_list")	
 	{

 		$cat_order=API_CAT_ORDER_BY;

 		$jsonObj_1= array();

		 
        $query_1="SELECT cid,category_name,category_image FROM tbl_category WHERE `status`='1' ORDER BY tbl_category.".$cat_order."";          

		$sql_1 = mysqli_query($mysqli,$query_1)or die(mysqli_error());

		while($data_1 = mysqli_fetch_assoc($sql_1))
		{
			$qry_quotes1="SELECT COUNT(*) as num FROM tbl_quotes WHERE cat_id='".$data_1['cid']."'";
			$total_quotes1= mysqli_fetch_array(mysqli_query($mysqli,$qry_quotes1));
			$total_quotes1 = $total_quotes1['num'];

			if($total_quotes1!=0)
			{
				$row_1['cid'] = $data_1['cid'];
				$row_1['category_name'] = $data_1['category_name'];
				$row_1['category_image'] = $file_path.'images/'.$data_1['category_image'];
				$row_1['category_image_thumb'] = get_thumb('images/'.$data_1['category_image'],'300x300');

				array_push($jsonObj_1,$row_1);			 
			}

		}

		$row['text_quotes_cat']=$jsonObj_1;

		$jsonObj_2= array();

		 
        $query_2="SELECT cid,category_name,category_image FROM tbl_category WHERE `status`='1' ORDER BY tbl_category.".$cat_order."";          

		$sql_2 = mysqli_query($mysqli,$query_2)or die(mysqli_error());

		while($data_2 = mysqli_fetch_assoc($sql_2))
		{
			$qry_quotes="SELECT COUNT(*) as num FROM tbl_img_quotes WHERE cat_id='".$data_2['cid']."' AND tbl_img_quotes.status=1";
			$total_quotes= mysqli_fetch_array(mysqli_query($mysqli,$qry_quotes));
			$total_quotes = $total_quotes['num'];

			if($total_quotes!=0)
			{
				$row_2['cid'] = $data_2['cid'];
				$row_2['category_name'] = $data_2['category_name'];
				$row_2['category_image'] = $file_path.'images/'.$data_2['category_image'];
				$row_2['category_image_thumb'] = get_thumb('images/'.$data_2['category_image'],'300x300');

				array_push($jsonObj_2,$row_2);	  
			}
			 
		
		}

		$row['image_quotes_cat']=$jsonObj_2;

 		$set['QUOTES_DIARY'] = $row;

		header( 'Content-Type: application/json' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();
 	}
	else  if($get_method['method_name']=="get_category_users")	
  	{
			 
		 $cat_order=API_CAT_ORDER_BY;
	
		 $jsonObj= array();
	
		 
		$query_1="SELECT cid,category_name,category_image FROM tbl_category WHERE `status`='1' ORDER BY tbl_category.".$cat_order."";          
	
		$sql_1 = mysqli_query($mysqli,$query_1)or die(mysqli_error());
	
		while($data_1 = mysqli_fetch_assoc($sql_1))
		{
		  
			$row_1['cid'] = $data_1['cid'];
			$row_1['category_name'] = $data_1['category_name'];
			$row_1['category_image'] = $file_path.'images/'.$data_1['category_image'];
			$row_1['category_image_thumb'] = $file_path.'images/thumbs/'.$data_1['category_image'];     
	
		   array_push($jsonObj,$row_1);
		
		}

		$set['QUOTES_DIARY'] = $jsonObj;

  		header( 'Content-Type: application/json' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();
  	}
   
	else  if($get_method['method_name']=="get_text_like")	
	{		 

    	//search if the user(ip) has already gave a note

    	$device_id = $get_method['device_id'];
    	$like = $get_method['like'];
    	$quotes_id = $get_method['quote_id'];
	

    	$query1 = mysqli_query($mysqli,"select * from tbl_like where quotes_id='$quotes_id' && device_id='$device_id' "); 
    	while($data1 = mysqli_fetch_assoc($query1)){
    		$rate_db1[] = $data1;
    	} 
    	if(count($rate_db1) == 0 ){ 
    		$data = array(
           		'quotes_id' =>$quotes_id ,
           		'device_id'  => $device_id,
           		'likes'  =>  '1',
           );  
 
     	  $qry = Insert('tbl_like',$data); 
 
					//Total like result 

				$query = mysqli_query($mysqli,"select SUM(likes) AS total_likes from tbl_like where quotes_id='$quotes_id'"); 
        		$row = mysqli_fetch_assoc($query); 
        		$total_likes = $row['total_likes'];
        
			 
				$data = array(	
					'quotes_likes'  =>  $total_likes
				);

		    $category_edit=Update('tbl_quotes', $data, "WHERE id = '".$quotes_id."'");	

				echo '{"QUOTES_DIARY":[{"msg":"Like","success":1}]}'; 
        exit;

    	}else{
    		

        $query = mysqli_query($mysqli,"select quotes_likes from tbl_quotes where id=$quotes_id"); 
        $row = mysqli_fetch_assoc($query);         
        $total_likes = $row['quotes_likes']-1;

        $data = array(  
          'quotes_likes'  =>  $total_likes
        );

        $quates_edit=Update('tbl_quotes', $data, "WHERE id = '".$quotes_id."'");   

        $cat_result=mysqli_query($mysqli,"DELETE FROM `tbl_like` WHERE device_id='$device_id' and quotes_id='$quotes_id'");

 
				echo '{"QUOTES_DIARY":[{"msg":"Unlike","success":0}]}';
        exit;

    	}
 
	}
	else  if($get_method['method_name']=="get_image_like")	
	{		 

    	//search if the user(ip) has already gave a note

    	$device_id = $get_method['device_id'];
    	$like = $get_method['like'];
    	$quotes_id = $get_method['quote_id'];
	

    	$query1 = mysqli_query($mysqli,"select * from tbl_img_like where quotes_id='$quotes_id' && device_id='$device_id' "); 
    	while($data1 = mysqli_fetch_assoc($query1)){
    		$rate_db1[] = $data1;
    	} 
    	if(count($rate_db1) == 0){ 
			$data = array(
				'quotes_id' =>$quotes_id ,
				'device_id'  => $device_id,
				'likes'  =>  $like,
			);  

			$qry = Insert('tbl_img_like',$data); 

			//Total like result 

			$query = mysqli_query($mysqli,"select SUM(likes) AS total_likes from tbl_img_like where quotes_id='$quotes_id'"); 
			$row = mysqli_fetch_assoc($query); 
			$total_likes = $row['total_likes'];


			$data = array(	
			'quotes_likes'  =>  $total_likes
			);

			$category_edit=Update('tbl_img_quotes', $data, "WHERE id = '".$quotes_id."'");	

			echo '{"QUOTES_DIARY":[{"msg":"Like","success":1}]}'; 
			exit;

    	}else{


			$query = mysqli_query($mysqli,"select quotes_likes from tbl_img_quotes where id='$quotes_id'"); 
			$row = mysqli_fetch_assoc($query); 
			$total_likes = $row['quotes_likes']-1;

			$data = array(  
				'quotes_likes'  =>  $total_likes
			);

			$quates_edit=Update('tbl_img_quotes', $data, "WHERE id = '".$quotes_id."'");   

			$cat_result=mysqli_query($mysqli,"DELETE FROM `tbl_img_like` WHERE device_id='$device_id' and quotes_id='$quotes_id'");


			echo '{"QUOTES_DIARY":[{"msg":"Unlike","success":0}]}';
			exit;

    	}
 
	}
  
  	else if($get_method['method_name']=="user_register")
  	{

			 	  
		$qry = "SELECT * FROM tbl_users WHERE email = '".$get_method['email']."'"; 
		$result = mysqli_query($mysqli,$qry);
		$row = mysqli_fetch_assoc($result);
		
		if (!filter_var($get_method['email'], FILTER_VALIDATE_EMAIL)) 
		{
			$set['QUOTES_DIARY'][]=array('msg' => $app_lang['invalid_email_format'],'success'=>'0');
		}
		else if($row['email']!="")
		{
			$set['QUOTES_DIARY'][]=array('msg' => $app_lang['email_exist'],'success'=>'0');
		}
		else
		{ 
 			 
			$data = array(
				'user_type'=>'Normal',											 
				'name'  => $get_method['name'],				    
				'email'  =>  $get_method['email'],
				'password'  =>  $get_method['password'],
				'phone'  =>  $get_method['phone'], 
				'status'  =>  '1'
			);		
 			 

			$qry = Insert('tbl_users',$data);									 
					 
				
			$set['QUOTES_DIARY'][]=array('msg' => $app_lang['register_success'],'success'=>'1');
					
		}


		header( 'Content-Type: application/json' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();
  	}
	else if($get_method['method_name']=="user_login")
	{

		$email= addslashes(trim($get_method['email']));
		$password = addslashes(trim($get_method['password']));

		$qry = "SELECT * FROM tbl_users WHERE status='1' and email = '".$email."' and password = '".$password."'"; 
		$result = mysqli_query($mysqli,$qry);
		$num_rows = mysqli_num_rows($result);
		$row = mysqli_fetch_assoc($result);

		if ($num_rows > 0)
		{ 

			$set['QUOTES_DIARY'][]=array('user_id' => $row['id'],'name'=>$row['name'],'success'=>'1');

		}		 
		else
		{
			$set['QUOTES_DIARY'][]=array('msg' =>$app_lang['login_fail'],'success'=>'0');
		}



		header( 'Content-Type: application/json' );
		echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();
	}
	else if($get_method['method_name']=="user_profile")
	{

		$qry = "SELECT * FROM tbl_users WHERE id = '".$get_method['id']."'"; 
		$result = mysqli_query($mysqli,$qry);

		$row = mysqli_fetch_assoc($result);
			 

		$set['QUOTES_DIARY'][]=array('user_id' => $row['id'],'name'=>$row['name'],'email'=>$row['email'],'phone'=>$row['phone'],'success'=>'1');



		header( 'Content-Type: application/json' );
		echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();
	}
  
	else if($get_method['method_name']=="user_profile_update")
	{

		$qry = "SELECT * FROM tbl_users WHERE email = '".$get_method['email']."'"; 
		$result = mysqli_query($mysqli,$qry);
		$row = mysqli_fetch_assoc($result);

		if (!filter_var($get_method['email'], FILTER_VALIDATE_EMAIL)) 
		{
			$set['QUOTES_DIARY'][]=array('msg' => $app_lang['invalid_email_format'],'success'=>'0');

			header( 'Content-Type: application/json' );
			$json = json_encode($set);
			echo $json;
			exit;
		}
		else if($row['email']==$get_method['email'] AND $row['id']!=$get_method['user_id'])
		{
			$set['QUOTES_DIARY'][]=array('msg' => $app_lang['email_exist'],'success'=>'0');

			header( 'Content-Type: application/json' );
			$json = json_encode($set);
			echo $json;
			exit;
		}
		else if($get_method['password']!="")
		{
			$data = array(
				'name'  =>  $get_method['name'],
				'email'  =>  $get_method['email'],
				'password'  =>  $get_method['password'],
				'phone'  =>  $get_method['phone'] 
			);
		}
		else
		{
			$data = array(
				'name'  =>  $get_method['name'],
				'email'  =>  $get_method['email'],			 
				'phone'  =>  $get_method['phone'] 
			);
		}


		$user_edit=Update('tbl_users', $data, "WHERE id = '".$get_method['user_id']."'");

				 
		$set['QUOTES_DIARY'][]=array('msg'=>$app_lang['update_success'],'success'=>'1');		 


		header( 'Content-Type: application/json' );
		echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();
  	}
  	else if($get_method['method_name']=="forgot_pass")
  	{
  		$host = $_SERVER['HTTP_HOST'];
		preg_match("/[^\.\/]+\.[^\.\/]+$/", $host, $matches);
        $domain_name=$matches[0];
         
	 	 
		$qry = "SELECT * FROM tbl_users WHERE email = '".$get_method['user_email']."'"; 
		$result = mysqli_query($mysqli,$qry);
		$row = mysqli_fetch_assoc($result);
		
		if($row['email']!="")
		{
 
			$to = $row['email'];
			$recipient_name=$row['name'];
			// subject
			$subject = '[IMPORTANT] '.APP_NAME.' Forgot Password Information';
 			
			$message='<div style="background-color: #f9f9f9;" align="center"><br />
					  <table style="font-family: OpenSans,sans-serif; color: #666666;" border="0" width="600" cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF">
					    <tbody>
					      <tr>
					        <td colspan="2" bgcolor="#FFFFFF" align="center"><img src="http://'.$_SERVER['SERVER_NAME'] . dirname($_SERVER['REQUEST_URI']).'/images/'.APP_LOGO.'" alt="header" /></td>
					      </tr>
					      <tr>
					        <td width="600" valign="top" bgcolor="#FFFFFF"><br>
					          <table style="font-family:OpenSans,sans-serif; color: #666666; font-size: 10px; padding: 15px;" border="0" width="100%" cellspacing="0" cellpadding="0" align="left">
					            <tbody>
					              <tr>
					                <td valign="top"><table border="0" align="left" cellpadding="0" cellspacing="0" style="font-family:OpenSans,sans-serif; color: #666666; font-size: 10px; width:100%;">
					                    <tbody>
					                      <tr>
					                        <td><p style="color: #262626; font-size: 28px; margin-top:0px;"><strong>Dear '.$row['name'].'</strong></p>
					                          <p style="color:#262626; font-size:20px; line-height:32px;font-weight:500;">Thank you for using '.APP_NAME.',<br>
					                            Your password is: '.$row['password'].'</p>
					                          <p style="color:#262626; font-size:20px; line-height:32px;font-weight:500;margin-bottom:30px;">Thanks you,<br />
					                            '.APP_NAME.'.</p></td>
					                      </tr>
					                    </tbody>
					                  </table></td>
					              </tr>
					               
					            </tbody>
					          </table></td>
					      </tr>
					      <tr>
					        <td style="color: #262626; padding: 20px 0; font-size: 20px; border-top:5px solid #52bfd3;" colspan="2" align="center" bgcolor="#ffffff">Copyright © '.APP_NAME.'.</td>
					      </tr>
					    </tbody>
					  </table>
					</div>';


			send_email($to,$recipient_name,$subject,$message);

			$set['QUOTES_DIARY'][]=array('msg' => $app_lang['password_sent_mail'],'success'=>'1');
		}
		else
		{  	 
				
			$set['QUOTES_DIARY'][]=array('msg' => $app_lang['email_not_found'],'success'=>'0');
					
		}

		header( 'Content-Type: application/json' );
	echo $val= json_encode($set);
		die();

  	}
	else if($get_method['method_name']=="text_quotes")	
	{		 

		$data = array( 
			'user_id'  =>  $get_method['user_id'],
			'cat_id'  =>  $get_method['cat_id'],
			'quote'  =>  addslashes($get_method['q_text']),
			'status'  =>  0
		); 


		$qry = Insert('tbl_quotes',$data);  

		$set['QUOTES_DIARY'][] = array('msg'=>'Quote has been uploaded!','success'=>1);
		header( 'Content-Type: application/json' );
		echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();
			
	}
	else if($get_method['method_name']=="image_quotes")	
	{		 

		$file_name= str_replace(" ","-",$_FILES['quote_image']['name']);             
		$albumimgnm=rand(0,99999)."_".$file_name;

		//Main Image
		$tpath1='images/'.$albumimgnm;       
		$pic1=compress_image($_FILES["quote_image"]["tmp_name"], $tpath1, 80);

		$data = array( 
			'user_id'  =>  $get_method['user_id'],
			'cat_id'  =>  $get_method['cat_id'],
			'quote_image'  => $albumimgnm,
			'status'  =>  0
		); 


		$qry = Insert('tbl_img_quotes',$data);  

		$set['QUOTES_DIARY'][] = array('msg'=>'Quote has been uploaded!','success'=>1);

		header( 'Content-Type: application/json' );
		echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();
    }
  	else if($get_method['method_name']=="get_text_quotes_cat_id")	
	{
		 
		$cat_id=$get_method['text_quotes_cat_id'];


		$limit=($get_method['page']-1) * 30;
 			$query_rec = "SELECT COUNT(*) as num FROM tbl_quotes
			LEFT JOIN tbl_category ON tbl_quotes.`cat_id`= tbl_category.`cid` 
			WHERE tbl_quotes.`cat_id`='$cat_id' AND tbl_category.`status`='1' AND tbl_quotes.`status`='1'";

		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query_rec));	

		$jsonObj= array();	
	
	    $query="SELECT * FROM tbl_quotes
			LEFT JOIN tbl_category ON tbl_quotes.`cat_id`= tbl_category.`cid` 
			WHERE tbl_quotes.`cat_id`='$cat_id' AND tbl_category.`status`='1' AND tbl_quotes.`status`='1' ORDER BY tbl_quotes.`id` DESC LIMIT $limit, 30";

		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			$row['num'] = $total_pages['num'];
			$row['id'] = $data['id'];
			$row['cat_id'] = $data['cat_id'];		  
  		 	$row['quote'] = stripslashes($data['quote']);	 

  		 	$row['quotes_likes'] = $data['quotes_likes'];
 			$row['total_views'] = $data['total_views'];
			$row['total_download'] = $data['total_download'];

			$query_like = mysqli_query($mysqli,"select * from tbl_like where quotes_id='".$data['id']."' && device_id='".$get_method['device_id']."' "); 
    			$num_rows1 = mysqli_num_rows($query_like);
 		
            if ($num_rows1 > 0)
		    {
    			$row['already_like']=true;
    		}
    		else
    		{
    			$row['already_like']=false;
    		}

			$row['cid'] = $data['cid'];
			$row['category_name'] = $data['category_name'];
			$row['category_image'] = $file_path.'images/'.$data['category_image'];
			$row['category_image_thumb'] = get_thumb('images/'.$data['category_image'],'300x300');

			array_push($jsonObj,$row);
		
		}

		$set['QUOTES_DIARY'] = $jsonObj;
		
		header( 'Content-Type: application/json' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();

		
	}
  	else if($get_method['method_name']=="get_image_quotes_cat_id")	
	{
		 
		$cat_id=$get_method['image_quotes_cat_id'];	

		$limit=($get_method['page']-1) * 30;
 		$query_rec = "SELECT COUNT(*) as num FROM tbl_img_quotes
			LEFT JOIN tbl_category ON tbl_img_quotes.`cat_id`= tbl_category.`cid` 
			WHERE tbl_img_quotes.`cat_id`='$cat_id' AND tbl_category.`status`='1' AND tbl_img_quotes.`status`='1'";
		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query_rec));

		$jsonObj= array();	
	
	    $query="SELECT * FROM tbl_img_quotes
			LEFT JOIN tbl_category ON tbl_img_quotes.`cat_id`=tbl_category.`cid` 
			WHERE tbl_img_quotes.`cat_id`='$cat_id' AND tbl_img_quotes.`status`='1' ORDER BY tbl_img_quotes.`id` DESC LIMIT $limit, 30";

		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			$row['num'] = $total_pages['num'];
			$row['id'] = $data['id'];
			$row['cat_id'] = $data['cat_id'];		  
  		 	$row['quote_image_b'] = $file_path.'images/'.$data['quote_image'];
		    $row['quote_image_s'] = get_thumb('images/'.$data['quote_image'],'300x300');

		    $row['quotes_likes'] = $data['quotes_likes'];
 			$row['total_views'] = $data['total_views'];
			$row['total_download'] = $data['total_download'];

			$query_like = mysqli_query($mysqli,"select * from tbl_img_like where quotes_id='".$data['id']."' && device_id='".$get_method['device_id']."' "); 
    			$num_rows1 = mysqli_num_rows($query_like);
 		
            if ($num_rows1 > 0)
		    {
    			$row['already_like']=true;
    		}
    		else
    		{
    			$row['already_like']=false;
    		}

			$row['cid'] = $data['cid'];
			$row['category_name'] = $data['category_name'];
			$row['category_image'] = $file_path.'images/'.$data['category_image'];
			$row['category_image_thumb'] = get_thumb('images/'.$data['category_image'],'300x300');

			array_push($jsonObj,$row);
		
		}

		$set['QUOTES_DIARY'] = $jsonObj;
		
		header( 'Content-Type: application/json' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();

		
	}
  	else if($get_method['method_name']=="get_text_single_quotes_id")	
	{
		 
		$quotes_id=$get_method['text_single_quotes_id'];	

		$jsonObj= array();	
	
	    $query="SELECT * FROM tbl_quotes
			LEFT JOIN tbl_category ON tbl_quotes.`cat_id`= tbl_category.`cid` 
			WHERE tbl_quotes.`id`='$quotes_id' AND tbl_category.`status`='1'";

		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			$row['id'] = $data['id'];
			$row['cat_id'] = $data['cat_id'];		  
  		 	$row['quote'] = stripslashes($data['quote']);	 

  		 	$row['quotes_likes'] = $data['quotes_likes'];
 			$row['total_views'] = $data['total_views'];
			$row['total_download'] = $data['total_download'];

			$query_like = mysqli_query($mysqli,"select * from tbl_like where quotes_id='".$data['id']."' && device_id='".$get_method['device_id']."' "); 
    			$num_rows1 = mysqli_num_rows($query_like);
 		
            if ($num_rows1 > 0)
		    {
    			$row['already_like']=true;
    		}
    		else
    		{
    			$row['already_like']=false;
    		}

			$row['cid'] = $data['cid'];
			$row['category_name'] = $data['category_name'];
			$row['category_image'] = $file_path.'images/'.$data['category_image'];
			$row['category_image_thumb'] = get_thumb('images/'.$data['category_image'],'300x300');
			 

			array_push($jsonObj,$row);
		
		}

		$view_qry=mysqli_query($mysqli,"UPDATE tbl_quotes SET total_views = total_views + 1 WHERE id = '".$quotes_id."'");

		$set['QUOTES_DIARY'] = $jsonObj;
		
		header( 'Content-Type: application/json' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();

		
	}
 	else if($get_method['method_name']=="get_image_single_quotes_id")	
	{
		 
		$quotes_id=$get_method['image_single_quotes_id'];	

		$jsonObj= array();	
	
	    $query="SELECT * FROM tbl_img_quotes
			LEFT JOIN tbl_category ON tbl_img_quotes.`cat_id`= tbl_category.`cid` 
			WHERE tbl_img_quotes.`id`='$quotes_id' AND tbl_category.`status`='1'";

		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			$row['id'] = $data['id'];
			$row['cat_id'] = $data['cat_id'];		  
  		 	$row['quote_image_b'] = $file_path.'images/'.$data['quote_image'];
		    $row['quote_image_s'] = get_thumb('images/'.$data['quote_image'],'300x300');

		    $row['quotes_likes'] = $data['quotes_likes'];
 			$row['total_views'] = $data['total_views'];
			$row['total_download'] = $data['total_download'];

			$query_like = mysqli_query($mysqli,"select * from tbl_img_like where quotes_id='".$data['id']."' && device_id='".$get_method['device_id']."' "); 
    			$num_rows1 = mysqli_num_rows($query_like);
 		
            if ($num_rows1 > 0)
		    {
    			$row['already_like']=true;
    		}
    		else
    		{
    			$row['already_like']=false;
    		}

			$row['cid'] = $data['cid'];
			$row['category_name'] = $data['category_name'];
			$row['category_image'] = $file_path.'images/'.$data['category_image'];
			$row['category_image_thumb'] = get_thumb('images/'.$data['category_image'],'300x300');
			 

			array_push($jsonObj,$row);
		
		}

		$view_qry=mysqli_query($mysqli,"UPDATE tbl_img_quotes SET total_views = total_views + 1 WHERE id = '".$quotes_id."'");

		$set['QUOTES_DIARY'] = $jsonObj;
		
		header( 'Content-Type: application/json' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();

		
	}
 	else if($get_method['method_name']=="text_quotes_popular")	
	{
		
		$limit=($get_method['page']-1) * 30;
 		$query_rec = "SELECT COUNT(*) as num FROM tbl_quotes
			LEFT JOIN tbl_category ON tbl_quotes.`cat_id`= tbl_category.`cid` 
			WHERE tbl_quotes.`status`='1' AND tbl_category.`status`='1' AND tbl_quotes.`total_views` > 0 ORDER BY tbl_quotes.`total_views` DESC";
		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query_rec)); 
 
		$jsonObj= array();	
	
	    $query="SELECT * FROM tbl_quotes
			LEFT JOIN tbl_category ON tbl_quotes.`cat_id`= tbl_category.`cid` 
			WHERE tbl_quotes.`status`='1' AND tbl_category.`status`='1' AND tbl_quotes.`total_views` > 0 ORDER BY tbl_quotes.`total_views` DESC LIMIT $limit, 30";

		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			$row['num'] = $total_pages['num'];
			$row['id'] = $data['id'];
			$row['cat_id'] = $data['cat_id'];		  
  		 	$row['quote'] = stripslashes($data['quote']);	 

  		 	$row['quotes_likes'] = $data['quotes_likes'];
 			$row['total_views'] = $data['total_views'];
			$row['total_download'] = $data['total_download'];

			$query_like = mysqli_query($mysqli,"select * from tbl_like where quotes_id='".$data['id']."' && device_id='".$get_method['device_id']."' "); 
    			$num_rows1 = mysqli_num_rows($query_like);
 		
            if ($num_rows1 > 0)
		    {
    			$row['already_like']=true;
    		}
    		else
    		{
    			$row['already_like']=false;
    		}

			$row['cid'] = $data['cid'];
			$row['category_name'] = $data['category_name'];
			$row['category_image'] = $file_path.'images/'.$data['category_image'];
			$row['category_image_thumb'] = get_thumb('images/'.$data['category_image'],'300x300');
			 

			array_push($jsonObj,$row);
		
		}

		$set['QUOTES_DIARY'] = $jsonObj;
		
		header( 'Content-Type: application/json' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();

		
	}
    else if($get_method['method_name']=="image_quotes_popular")	
	{
		$limit=($get_method['page']-1) * 30;

 		$query_rec = "SELECT COUNT(*) as num FROM tbl_img_quotes
			LEFT JOIN tbl_category ON tbl_img_quotes.`cat_id`= tbl_category.`cid` 
			WHERE tbl_img_quotes.`status`='1' AND tbl_category.`status`='1' AND tbl_img_quotes.`total_views` > 0 ORDER BY tbl_img_quotes.`total_views` DESC";

		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query_rec));

		$jsonObj= array();	
	
	    $query="SELECT * FROM tbl_img_quotes
		LEFT JOIN tbl_category ON tbl_img_quotes.`cat_id`= tbl_category.`cid` 
		WHERE tbl_img_quotes.`status`='1' AND tbl_img_quotes.`total_views` > 0 ORDER BY tbl_img_quotes.`total_views` DESC LIMIT $limit, 30";

		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			$row['num'] = $total_pages['num'];
			$row['id'] = $data['id'];
			$row['cat_id'] = $data['cat_id'];		  
  		 	$row['quote_image_b'] = $file_path.'images/'.$data['quote_image'];
		    $row['quote_image_s'] = get_thumb('images/'.$data['quote_image'],'300x300');

		    $row['quotes_likes'] = $data['quotes_likes'];
 			$row['total_views'] = $data['total_views'];
			$row['total_download'] = $data['total_download'];

			$query_like = mysqli_query($mysqli,"select * from tbl_img_like where quotes_id='".$data['id']."' && device_id='".$get_method['device_id']."' "); 
    			$num_rows1 = mysqli_num_rows($query_like);
 		
            if ($num_rows1 > 0)
		    {
    			$row['already_like']=true;
    		}
    		else
    		{
    			$row['already_like']=false;
    		}

			$row['cid'] = $data['cid'];
			$row['category_name'] = $data['category_name'];
			$row['category_image'] = $file_path.'images/'.$data['category_image'];
			$row['category_image_thumb'] = get_thumb('images/'.$data['category_image'],'300x300');
			 

			array_push($jsonObj,$row);
		
		}

		$set['QUOTES_DIARY'] = $jsonObj;
		
		header( 'Content-Type: application/json' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();

		
	}
 	else if($get_method['method_name']=="text_quotes_top_likes")	
	{
		
		$limit=($get_method['page']-1) * 30;
 		$query_rec = "SELECT COUNT(*) as num FROM tbl_quotes
			LEFT JOIN tbl_category ON tbl_quotes.`cat_id`= tbl_category.`cid` 
			WHERE tbl_quotes.`status`='1' AND tbl_category.`status`='1' AND tbl_quotes.`quotes_likes` > 0 ORDER BY tbl_quotes.`quotes_likes` DESC";
		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query_rec)); 
 
		$jsonObj= array();	
	
	    $query="SELECT * FROM tbl_quotes
		LEFT JOIN tbl_category ON tbl_quotes.`cat_id`= tbl_category.`cid` 
		WHERE tbl_quotes.`status`='1' AND tbl_category.`status`='1' AND tbl_quotes.`quotes_likes` > 0 ORDER BY tbl_quotes.`quotes_likes` DESC LIMIT $limit, 30";

		$sql = mysqli_query($mysqli,$query)or die(mysqli_error($mysqli));

		while($data = mysqli_fetch_assoc($sql))
		{
			$row['num'] = $total_pages['num'];
			$row['id'] = $data['id'];
			$row['cat_id'] = $data['cat_id'];		  
  		 	$row['quote'] = stripslashes($data['quote']);	 

  		 	$row['quotes_likes'] = $data['quotes_likes'];
 			$row['total_views'] = $data['total_views'];
			$row['total_download'] = $data['total_download'];

			$query_like = mysqli_query($mysqli,"select * from tbl_like where quotes_id='".$data['id']."' && device_id='".$get_method['device_id']."' "); 
    			$num_rows1 = mysqli_num_rows($query_like);
 		
            if ($num_rows1 > 0)
		    {
    			$row['already_like']=true;
    		}
    		else
    		{
    			$row['already_like']=false;
    		}

			$row['cid'] = $data['cid'];
			$row['category_name'] = $data['category_name'];
			$row['category_image'] = $file_path.'images/'.$data['category_image'];
			$row['category_image_thumb'] = get_thumb('images/'.$data['category_image'],'300x300');
			 

			array_push($jsonObj,$row);
		
		}

		$set['QUOTES_DIARY'] = $jsonObj;
		
		header( 'Content-Type: application/json' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();

		
	}
 	else if($get_method['method_name']=="image_quotes_top_likes")	
	{
		$limit=($get_method['page']-1) * 30;

 		$query_rec = "SELECT COUNT(*) as num FROM tbl_img_quotes
			LEFT JOIN tbl_category ON tbl_img_quotes.`cat_id`= tbl_category.`cid` 
			WHERE tbl_img_quotes.`status`='1' AND tbl_category.`status`='1' AND tbl_img_quotes.`quotes_likes` > 0 ORDER BY tbl_img_quotes.`quotes_likes` DESC";
		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query_rec));

		$jsonObj= array();	
	
	    $query="SELECT * FROM tbl_img_quotes
			LEFT JOIN tbl_category ON tbl_img_quotes.`cat_id`= tbl_category.`cid` 
			WHERE tbl_img_quotes.`status`='1' AND tbl_category.`status`='1' AND tbl_img_quotes.`quotes_likes` > 0 ORDER BY tbl_img_quotes.`quotes_likes` DESC LIMIT $limit, 30";

		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			$row['num'] = $total_pages['num'];
			$row['id'] = $data['id'];
			$row['cat_id'] = $data['cat_id'];		  
  		 	$row['quote_image_b'] = $file_path.'images/'.$data['quote_image'];
		    $row['quote_image_s'] = get_thumb('images/'.$data['quote_image'],'300x300');

		    $row['quotes_likes'] = $data['quotes_likes'];
 			$row['total_views'] = $data['total_views'];
			$row['total_download'] = $data['total_download'];

			$query_like = mysqli_query($mysqli,"select * from tbl_img_like where quotes_id='".$data['id']."' && device_id='".$get_method['device_id']."' "); 
    			$num_rows1 = mysqli_num_rows($query_like);
 		
            if ($num_rows1 > 0)
		    {
    			$row['already_like']=true;
    		}
    		else
    		{
    			$row['already_like']=false;
    		}

			$row['cid'] = $data['cid'];
			$row['category_name'] = $data['category_name'];
			$row['category_image'] = $file_path.'images/'.$data['category_image'];
			$row['category_image_thumb'] = get_thumb('images/'.$data['category_image'],'300x300');
			 

			array_push($jsonObj,$row);
		
		}

		$set['QUOTES_DIARY'] = $jsonObj;
		
		header( 'Content-Type: application/json' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();

		
	}
 	else if($get_method['method_name']=="get_quotes_download")	
	{
		$jsonObj= array();		
		 
		$view_qry=mysqli_query($mysqli,"UPDATE tbl_img_quotes SET total_download = total_download + 1 WHERE id = '".$get_method['quotes_download_id']."'");
 	 

    	$total_dw_sql="SELECT * FROM tbl_img_quotes WHERE id='".$get_method['quotes_download_id']."'";
	    $total_dw_res=mysqli_query($mysqli,$total_dw_sql);
	    $total_dw_row=mysqli_fetch_assoc($total_dw_res);
	    
	         
        $jsonObj = array( 'total_download' => $total_dw_row['total_download']);

        $set['QUOTES_DIARY'][] = $jsonObj;
        header( 'Content-Type: application/json' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();
	}	 
  	else if($get_method['method_name']=="get_app_details")
	{
		$jsonObj= array();	

		$query="SELECT * FROM tbl_settings WHERE id='1'";
		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			 
			$row['app_name'] = $data['app_name'];
			$row['app_logo'] = $data['app_logo'];
			$row['app_version'] = $data['app_version'];
			$row['app_author'] = $data['app_author'];
			$row['app_contact'] = $data['app_contact'];
			$row['app_email'] = $data['app_email'];
			$row['app_website'] = $data['app_website'];
			$row['app_description'] = $data['app_description'];
 			$row['app_developed_by'] = $data['app_developed_by'];

			$row['app_privacy_policy'] = stripslashes($data['app_privacy_policy']);
 			
 			$row['package_name'] = $data['package_name'];
 			$row['publisher_id'] = $data['publisher_id'];
			$row['interstital_ad'] = $data['interstital_ad'];
			$row['interstital_ad_id'] = $data['interstital_ad_id'];
			$row['interstital_ad_click'] = $data['interstital_ad_click'];
 			$row['banner_ad'] = $data['banner_ad'];
 			$row['banner_ad_id'] = $data['banner_ad_id'];
	

			array_push($jsonObj,$row);
	
		}

		$set['QUOTES_DIARY'] = $jsonObj;
		
		header( 'Content-Type: application/json' );
	    echo $val= json_encode($set);
		die();	
	}
	else if($get_method['method_name']=="quotes_report")
	{
		$jsonObj= array();	
		
		$type=$get_method['type'];
		$user_id=$get_method['user_id'];
		$report=$get_method['report'];
		$post_id=$get_method['post_id'];

		$data = array(
				'type' => $type,				    
			    'user_id'  => $user_id,				    
		    'post_id'  => $post_id,	
				'report'  =>  $report,
				'created_at'  => strtotime(date('d-m-Y h:i:s A'))
			);		
 			 

		$qry = Insert('tbl_reports',$data);									 
			
		$info['success']="1";	
		$info['msg']=$app_lang['report_sent'];

		array_push($jsonObj,$info);

		$set['QUOTES_DIARY'] = $jsonObj;
		
				 
		header( 'Content-Type: application/json' );
	echo $val= json_encode($set);
		die();

	}
	else
  	{
  		$get_method = checkSignSalt($_POST['data']);
  	} 
?>