<?php include("includes/header.php");

	require("includes/function.php");
	require("language/language.php");

require_once("configuration.php");
	require_once("thumbnail_images.class.php");
	
	 
	$cat_qry="SELECT * FROM category ORDER BY category desc";
	$cat_result=mysqli_query($mysqli,$cat_qry);
 
 if(isset($_FILES['video'])){
	   
      $errors= array();
      $videopath_name = $_FILES['video']['name'];
 
	  
	   $videopzip_name = $_FILES['zip']['name'];
	  
	   $videothumb_name = $_FILES['image']['name'];
	
      $expensions= array("jpeg","jpg","png");
      
 
    
    
	  $videotitle =   str_replace(".zip","",$videopzip_name);   /*$_POST['videotitle'];*/
	  $videocategory = $_POST['videocategory'];
      $videopath = "video1data/".str_replace(".zip",".mp4",$videopzip_name);/* .$videopath_name;*/
      $videozip = "video1zip/".$videopzip_name;
      $videothumb = "video1thumb/".str_replace(".zip",".jpg",$videopzip_name); /*.$videothumb_name;*/
	  
      //if(empty($errors)==true){
       move_uploaded_file($_FILES['video']['tmp_name'],$videopath);
		 
         move_uploaded_file($_FILES['zip']['tmp_name'],$videozip);
         move_uploaded_file($_FILES['image']['tmp_name'],$videothumb);
         //echo "Success";
    //  }else{
     //    print_r($errors);
     // }
	  $randomid = rand(100,200); 
 $qrry_1="INSERT INTO `videotable` (`title`, `category`, `count_images`, `video_zip`, `video_link`, `video_thumb`, `downloads`) VALUES( '".$videotitle."', '".$videocategory."' ,'0', '".$videozip."' , '".$videopath."' ,'".$videothumb ."','".$randomid."');";
 //echo $qrry_1;
			if(mysqli_query($conn,$qrry_1))
			{
			   $array_out = array();
    			$array_out[] = 
    				array(
    					"response" => "file uploaded"
    				);
    			
    			$output=array( "code" => "200", "msg" => $array_out);
    			print_r(json_encode($output, true)); 
			}
			else
			{
			    $array_out = array();
    			$array_out[] = 
    				array(
    				"response" => "error in uploading files"
    				);
    			echo mysqli_error($conn);
    			//$output=array( "code" => "201", "msg" => $array_out);
    			//print_r(json_encode($output, true)); 
			}
			
   }	
	 
?>
 

       <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="page_title_block">
            <div class="col-md-5 col-xs-12">
              <div class="page_title">Add Video Templates</div>
             
            </div>
          </div>
          <div class="clearfix"></div>
          <div class="card-body mrg_bottom">
            <form class="form form-horizontal" action="" method="post"  enctype="multipart/form-data">
              <div class="section">
                  
				   <strong style="font-size: 32px;">Note: Title & Zip file Name should be same.<br /> <br/></strong>
                  <div class="form">
                    <div class="form-group">
                      <label class="col-md-3 control-label">Title :-</label>
                    <div class="col-md-6">
                       
                          <input type="text" name="videotitle" class="form-control" placeholder="Oye Sunnn, Kuchh Mat likhna... Mai atma nirbhar hu" style="height:50px; width:100%;">
                   
                    </div>
                  </div>
                  </div>
                  
                <div class="section-body">
                    
                  
                  <div class="form-group">
                    <label class="col-md-3 control-label">Category :-</label>
                    <div class="col-md-6">
                      <select name="videocategory" class="select2" required>
                        <option value="">--Select Category--</option>
          							<?php
          									while($cat_row=mysqli_fetch_array($cat_result))
          									{
          							?>          						 
          							<option  value="<?php echo $cat_row['category'];?>"><?php echo $cat_row['category'];?></option>	          							 
          							<?php
          								}
          							?>
                      </select>
                    </div>
                  </div>
                    
                  <div class="form-group">
                    <label class="col-md-3 control-label">Video :-
                    </label>
                    <div class="col-md-6">
                      <div class="fileupload_block">
                        <input type="file" name="video" required>
                       
                      </div>
                    </div>
                  </div>
                    
                    <div class="form-group">
                    <label class="col-md-3 control-label">Zip :-
                    </label>
                    <div class="col-md-6">
                      <div class="fileupload_block">
                        <input  type="file" name="zip" required>
                      </div>
                    </div>
                  </div>
                  
                     <div class="form-group">
                    <label class="col-md-3 control-label">Thumb :-
                    </label>
                    <div class="col-md-6">
                      <div class="fileupload_block">
                        <input  type="file" name="image" required>
                      </div>
                    </div>
                  </div>
                  
                  <div class="form-group">&nbsp;</div>
                  <div class="form-group">
                    <div class="col-md-9 col-md-offset-3">
                      <button type="submit" name="submit" class="btn btn-primary">Upload</button>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>           
                 
        
<?php include("includes/footer.php");?>       
