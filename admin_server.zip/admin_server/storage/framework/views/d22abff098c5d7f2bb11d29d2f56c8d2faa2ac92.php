   <?php echo $__env->make('templates.headers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <?php echo $__env->make('templates.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <div class="content-wrapper pt-4">

       <section class="content">
           <div class="container-fluid">
               <?php echo $__env->yieldContent('content'); ?>
           </div>
       </section>
   </div>
   <?php echo $__env->make('templates.footers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\Documents\Programmer\robovpn\server\resources\views/templates/content.blade.php ENDPATH**/ ?>