</div>
<?php echo $__env->yieldContent('footer'); ?>
<script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/adminlte.js')); ?>"></script>
<?php echo $__env->yieldContent('javascripts'); ?>
</body>

</html>
<?php /**PATH C:\Users\Nizwar\Desktop\nerd_3.0\servers\resources\views/templates/footers.blade.php ENDPATH**/ ?>