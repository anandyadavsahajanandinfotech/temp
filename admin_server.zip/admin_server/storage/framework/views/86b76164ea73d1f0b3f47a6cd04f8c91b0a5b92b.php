</div>
<?php echo $__env->yieldContent('footer'); ?>
<script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/adminlte.js')); ?>"></script>
<?php echo $__env->yieldContent('javascripts'); ?>
</body>

</html>
<?php /**PATH D:\Documents\Programmer\robovpn\server\resources\views/templates/footers.blade.php ENDPATH**/ ?>