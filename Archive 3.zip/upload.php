<?php
require_once("configuration.php");
   if(isset($_FILES['video'])){
	   
      $errors= array();
      $videopath_name = $_FILES['video']['name'];
   //   $videopathext=strtolower(end(explode('.',$_FILES['video']['name'])));
	  
	   $videopzip_name = $_FILES['zip']['name'];
     // $videozipext=strtolower(end(explode('.',$_FILES['zip']['name'])));
	  
	   $videothumb_name = $_FILES['image']['name'];
     // $videothumbext=strtolower(end(explode('.',$_FILES['image']['name'])));
	  
           // $file_size =$_FILES['image']['size'];
      //$file_tmp =$_FILES['image']['tmp_name'];
    //  $file_type=$_FILES['image']['type'];
	
      $expensions= array("jpeg","jpg","png");
      
      //if(in_array($file_ext,$expensions)=== false){
     //    $errors[]="extension not allowed, please choose a JPEG or PNG file.";
     // }
      
     // if($file_size > 2097152){
       //  $errors[]='File size must be excately 2 MB';
    //  }
	  $videotitle = $_POST['videotitle'];
	  $videocategory = $_POST['videocategory'];
      $videopath = "video1data/".$videopath_name;
      $videozip = "video1zip/".$videopzip_name;
      $videothumb = "video1thumb/".$videothumb_name;
	  
      //if(empty($errors)==true){
       move_uploaded_file($_FILES['video']['tmp_name'],$videopath);
		 
         move_uploaded_file($_FILES['zip']['tmp_name'],$videozip);
         move_uploaded_file($_FILES['image']['tmp_name'],$videothumb);
         //echo "Success";
    //  }else{
     //    print_r($errors);
     // }
	  $randomid = rand(100,200); 
 $qrry_1="INSERT INTO `videotable` (`title`, `category`, `count_images`, `video_zip`, `video_link`, `video_thumb`, `downloads`) VALUES( '".$videotitle."', '".$videocategory."' ,'0', '".$videozip."' , '".$videopath."' ,'".$videothumb ."','".$randomid."');";
 //echo $qrry_1;
			if(mysqli_query($conn,$qrry_1))
			{
			   $array_out = array();
    			$array_out[] = 
    				array(
    					"response" => "file uploaded"
    				);
    			
    			$output=array( "code" => "200", "msg" => $array_out);
    			print_r(json_encode($output, true)); 
			}
			else
			{
			    //$array_out = array();
    			//$array_out[] = 
    			//	array(
    			//		"response" => "error in uploading files"
    			//	);
    			echo mysqli_error($conn);
    			//$output=array( "code" => "201", "msg" => $array_out);
    			//print_r(json_encode($output, true)); 
			}
			
   }
?>
<html>
   <body>
      
      <form action="" method="POST" enctype="multipart/form-data">
	  
	  <h6>------------title-------------</h6>
         <input type="text" name="videotitle" />
        		 
		 <h6>------------category-------------</h6>
         <input type="text" name="videocategory" />
       	  
	  <h6>------------video-------------</h6>
         <input type="file" name="video" />
        
		 
	  <h6>------------zip-------------</h6>
         <input type="file" name="zip" />
        
		 
		<h6>------------thumb-------------</h6>
         <input type="file" name="image" />
         <input type="submit"/>
      </form>
      
   </body>
</html>